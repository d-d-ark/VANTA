if (typeof importScripts === "function") importScripts("project-chunks.js");

(() => {
  "use strict";

  const FIREBASE = Object.freeze({
    apiKey: "AIzaSyCJT8QNhStr_5BVk0Eqng286SHL8-CdtA0",
    authDomain: "vanta-d760a.firebaseapp.com",
    databaseURL: "https://vanta-d760a-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "vanta-d760a",
    storageBucket: "vanta-d760a.firebasestorage.app",
    messagingSenderId: "63191859835",
    appId: "1:63191859835:web:8e32f4384144c4c6f998de",
  });
  const AUTH_KEY = "vanta.firebaseAuth";
  const INSTALLATION_ID_KEY = "vanta.installationId";
  const ACTIVE_LIVE_KEY = "vanta.activeLive";
  const LIVE_LEASE_MS = 45000;
  const AUTH_EXPIRY_MARGIN_MS = 60000;
  const MAX_PARTICIPANTS = 5;
  const PROTOCOL_VERSION = 3;
  const RELEASE_VERSION = 50;
  const SYNC_VERSION = 2;
  const CLIENT_VERSION = chrome.runtime.getManifest?.().version || "0";
  const API_ROOT = "vanta/v1/sessions";
  const SHORTENER_API = "https://llnk.kr/api/v1/shorten.php";
  const VANTA_SESSION_API = "https://llnk.kr/api/v1/vanta/sessions.php";
  const VANTA_SYNC_API = "https://llnk.kr/api/v1/vanta/sync.php";
  const VANTA_CHAT_API = "https://llnk.kr/api/v1/vanta/chat.php";
  const VANTA_CURSOR_API = "https://llnk.kr/api/v1/vanta/cursor.php";
  const VANTA_PRESENCE_API = "https://llnk.kr/api/v1/vanta/presence.php";
  const VANTA_QUOTA_API = "https://llnk.kr/api/v1/vanta/quota.php";
  const VANTA_SETTINGS_API = "https://llnk.kr/api/v1/vanta/settings.php";
  const SHORT_LINK_PREFIX = "vanta.shortLink.";
  const TOKEN_PATTERN = /^[A-Za-z0-9_-]{20,128}$/;
  const MAX_PROJECT_JSON_BYTES = 8 * 1024 * 1024;
  // Leave room for the signed identity and request metadata inside sync.php's
  // 2 MiB whole-request limit.
  const MAX_DELTA_JSON_BYTES = (2 * 1024 * 1024) - (16 * 1024);
  const CHAT_MAX_LENGTH = 100;
  const PRESENCE_REPORT_MS = 30000;
  const sessionQueues = new Map();
  const presenceReportTimes = new Map();
  let authPromise = null;
  let authPromiseToken = "";
  let liveQueue = Promise.resolve();

  function validateToken(value) {
    const token = String(value || "");
    if (!TOKEN_PATTERN.test(token)) throw new Error("VANTA 링크 코드가 올바르지 않습니다.");
    return token;
  }

  function liveIdentity(message) {
    const token = validateToken(message?.token);
    const participantId = String(message?.participantId || "");
    if (!participantId) throw new Error("VANTA Live 참가자 정보가 없습니다.");
    return { token, participantId };
  }

  function liveConnectionIdentity(message) {
    const identity = liveIdentity(message);
    const connectionId = String(message?.connectionId || "");
    if (!/^[A-Za-z0-9_-]{16,64}$/.test(connectionId)) {
      throw new Error("VANTA Live 연결 식별 정보가 없습니다.");
    }
    return { ...identity, connectionId };
  }

  function displayName(value) {
    const normalized = String(value || "")
      .replace(/[\u0000-\u001f\u007f]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    return Array.from(normalized || "참여자").slice(0, 20).join("");
  }

  function profileColor(value) {
    return /^#[0-9A-Fa-f]{6}$/.test(String(value || "")) ? String(value) : "#7351FF";
  }

  function participantRecord(auth, participantId, message, joinedAt, expiresAt) {
    return {
      uid: auth.uid,
      participantId,
      protocolVersion: PROTOCOL_VERSION,
      releaseVersion: RELEASE_VERSION,
      name: displayName(message?.name),
      color: profileColor(message?.color),
      joinedAt,
      expiresAt,
    };
  }

  function encodePath(path) {
    return String(path).split("/").map(encodeURIComponent).join("/");
  }

  function randomId(byteLength = 18) {
    const bytes = crypto.getRandomValues(new Uint8Array(byteLength));
    return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  }

  function encodeProject(project) {
    let encoded;
    try {
      encoded = JSON.stringify(project);
    } catch (_) {
      throw new Error("엔트리 작품 데이터를 저장할 수 없습니다.");
    }
    if (!encoded || new TextEncoder().encode(encoded).byteLength > MAX_PROJECT_JSON_BYTES) {
      throw new Error("VANTA로 공유하기에는 작품 데이터가 너무 큽니다.");
    }
    return encoded;
  }

  function decodeProject(stored) {
    if (typeof stored !== "string") return stored;
    try {
      const project = JSON.parse(stored);
      return project && typeof project === "object" ? project : null;
    } catch (_) {
      return null;
    }
  }

  function projectBundleFromChunks(rawChunks) {
    const bundle = {
      version: VantaProjectChunks.FORMAT_VERSION,
      chunks: rawChunks && typeof rawChunks === "object" ? rawChunks : {},
    };
    VantaProjectChunks.validateBundle(bundle);
    return VantaProjectChunks.clone(bundle);
  }

  function encodeProjectDelta(delta) {
    const normalized = VantaProjectChunks.validateDelta(delta);
    const encoded = JSON.stringify({ version: VantaProjectChunks.FORMAT_VERSION, ...normalized });
    if (new TextEncoder().encode(encoded).byteLength > MAX_DELTA_JSON_BYTES) {
      throw new Error("VANTA 변경 내용이 너무 큽니다.");
    }
    return { normalized, encoded };
  }

  function decodeProjectDelta(stored) {
    if (typeof stored !== "string") return null;
    try {
      const decoded = JSON.parse(stored);
      if (decoded?.full === true) return { full: true };
      if (Number(decoded?.version || 0) !== VantaProjectChunks.FORMAT_VERSION) return null;
      return VantaProjectChunks.validateDelta(decoded);
    } catch (_) {
      return null;
    }
  }

  async function getInstallationId() {
    const stored = await chrome.storage.local.get(INSTALLATION_ID_KEY);
    let installationId = String(stored[INSTALLATION_ID_KEY] || "");
    if (!TOKEN_PATTERN.test(installationId)) {
      installationId = randomId();
      await chrome.storage.local.set({ [INSTALLATION_ID_KEY]: installationId });
    }
    return installationId;
  }

  async function readStoredAuth() {
    const stored = await chrome.storage.local.get(AUTH_KEY);
    return stored[AUTH_KEY] || null;
  }

  async function saveAuth(payload, context = {}) {
    const expiresIn = Number(payload.expiresIn || payload.expires_in || 3600);
    const auth = {
      idToken: payload.idToken || payload.id_token,
      refreshToken: payload.refreshToken || payload.refresh_token || null,
      uid: payload.localId || payload.user_id || context.uid || null,
      expiresAt: Date.now() + expiresIn * 1000,
      roomToken: context.roomToken || null,
      roomAccessExpiresAt: Number(context.roomAccessExpiresAt || 0),
      participantId: String(context.participantId || ""),
      syncToken: context.syncToken || null,
      releaseVersion: Number(context.releaseVersion || 0),
    };
    if (!auth.idToken || !auth.uid || !auth.roomToken || auth.releaseVersion !== RELEASE_VERSION) {
      throw new Error("VANTA Firebase 인증 정보가 누락되었습니다.");
    }
    await chrome.storage.local.set({ [AUTH_KEY]: auth });
    return auth;
  }

  async function parseResponse(response) {
    const text = await response.text();
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (_) {
      return text;
    }
  }

  function firebaseError(payload, fallback) {
    const raw = String(payload?.error?.message || payload?.error || fallback || "Firebase 요청에 실패했습니다.");
    if (raw.includes("PERMISSION_DENIED")) return new Error("Firebase 실시간 데이터베이스 규칙이 아직 VANTA 접근을 허용하지 않습니다.");
    if (raw.includes("CONFIGURATION_NOT_FOUND")) return new Error("Firebase 익명 로그인이 활성화되지 않았습니다.");
    if (raw.includes("TOO_MANY_ATTEMPTS")) return new Error("Firebase 요청이 잠시 제한되었습니다. 잠시 후 다시 시도해 주세요.");
    return new Error(raw);
  }

  async function signInWithCustomToken(customToken, context) {
    const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${encodeURIComponent(FIREBASE.apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: customToken, returnSecureToken: true }),
    });
    const payload = await parseResponse(response);
    if (!response.ok) throw firebaseError(payload, "VANTA 방 인증에 실패했습니다.");
    return saveAuth(payload, context);
  }

  async function refreshAuth(stored) {
    const response = await fetch(`https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(FIREBASE.apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: stored.refreshToken }).toString(),
    });
    const payload = await parseResponse(response);
    if (!response.ok) return null;
    return saveAuth(payload, stored);
  }

  async function requestRoomAuthorization(action, token, details = {}) {
    token = validateToken(token);
    const installationId = await getInstallationId();
    const response = await fetch(VANTA_SESSION_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify({
        action,
        roomId: token,
        installationId,
        protocolVersion: PROTOCOL_VERSION,
        participantId: String(details.participantId || ""),
        ...(action === "create" ? {
          maxParticipants: Math.max(2, Math.min(5, Number(details.maxParticipants || MAX_PARTICIPANTS))),
        } : {}),
      }),
    });
    const payload = await parseResponse(response);
    if (!response.ok || payload?.ok === false) {
      if (response.status === 404) throw new Error("VANTA 세션을 찾을 수 없습니다. 링크를 다시 확인해 주세요.");
      if (response.status === 409) throw new Error("이미 사용 중인 VANTA 링크입니다.");
      if (response.status === 429) throw new Error(String(payload?.error || "VANTA 방 생성 한도에 도달했습니다."));
      throw new Error(String(payload?.error || "VANTA 방 인증 서버에 연결하지 못했습니다."));
    }
    if (payload?.roomId !== token || !payload?.customToken || Number(payload?.releaseVersion || 0) !== RELEASE_VERSION) {
      throw new Error("VANTA 최신 버전 인증을 받지 못했습니다.");
    }
    return signInWithCustomToken(payload.customToken, {
      roomToken: token,
      roomAccessExpiresAt: Number(payload.roomAccessExpiresAt || 0),
      uid: String(payload.uid || ""),
      participantId: String(details.participantId || ""),
      syncToken: payload.syncToken || null,
      releaseVersion: Number(payload.releaseVersion || 0),
    });
  }

  async function requestRoomClose(token) {
    token = validateToken(token);
    const installationId = await getInstallationId();
    const response = await fetch(VANTA_SESSION_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify({ action: "close", roomId: token, installationId, protocolVersion: PROTOCOL_VERSION }),
    });
    const payload = await parseResponse(response);
    if (!response.ok || payload?.ok === false) {
      throw new Error(String(payload?.error || "VANTA 빈 방 정리에 실패했습니다."));
    }
    return payload;
  }

  async function reportUsagePresence(action, token, participantId, name = "", force = false) {
    const key = `${token}|${participantId}`;
    const now = Date.now();
    if (action === "heartbeat" && !force && now - Number(presenceReportTimes.get(key) || 0) < PRESENCE_REPORT_MS - 5000) {
      return null;
    }
    const installationId = await getInstallationId();
    const auth = await getAuth(token, false, participantId);
    let response;
    try {
      response = await fetch(VANTA_PRESENCE_API, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${auth.syncToken}`,
          "Content-Type": "application/json",
          "X-VANTA-Version": CLIENT_VERSION,
        },
        body: JSON.stringify({ action, roomId: token, installationId, participantId, name: displayName(name) }),
      });
    } catch (_) {
      return null;
    }
    const payload = await parseResponse(response);
    if (response.status === 429) {
      throw new Error(String(payload?.error || "VANTA 토큰을 모두 사용했습니다."));
    }
    if (!response.ok || payload?.ok === false) return null;
    if (action === "leave") presenceReportTimes.delete(key);
    else presenceReportTimes.set(key, now);
    return payload;
  }

  function normalizeQuota(value) {
    const quota = value?.quota || value || {};
    const period = ["day", "week", "month"].includes(String(quota.period || "")) ? String(quota.period) : "week";
    const usedPercent = Math.max(0, Math.min(100, Number(quota.percent ?? quota.usedPercent ?? 0) || 0));
    const remainingPercent = Math.max(0, Math.min(100, Number(quota.remaining_percent ?? quota.remainingPercent ?? (100 - usedPercent)) || 0));
    return {
      period,
      periodLabel: String(quota.period_label ?? quota.periodLabel ?? (period === "day" ? "오늘" : period === "month" ? "이번 달" : "이번 주")),
      periodUnit: String(quota.period_unit ?? quota.periodUnit ?? (period === "day" ? "일" : period === "month" ? "월" : "주")),
      usedTokens: Math.max(0, Number(quota.used_tokens ?? quota.usedTokens ?? 0) || 0),
      limitTokens: Math.max(0, Number(quota.limit_tokens ?? quota.limitTokens ?? 0) || 0),
      remainingTokens: Math.max(0, Number(quota.remaining_tokens ?? quota.remainingTokens ?? 0) || 0),
      usedPercent,
      remainingPercent,
      resetAt: String(quota.reset_at ?? quota.resetAt ?? ""),
      paused: Boolean(quota.paused),
    };
  }

  async function getQuota() {
    const installationId = await getInstallationId();
    const response = await fetch(VANTA_QUOTA_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify({ installationId }),
    });
    const payload = await parseResponse(response);
    if (!response.ok || payload?.ok === false) {
      throw new Error(String(payload?.error || "Token을 확인하지 못했습니다."));
    }
    return normalizeQuota(payload);
  }

  async function requestRoomSettings(message, update = false, retryAuth = true) {
    const { token, participantId } = liveIdentity(message);
    const installationId = await getInstallationId();
    const auth = await getAuth(token, false, participantId);
    const body = {
      action: update ? "update" : "get",
      roomId: token,
      installationId,
      participantId,
      syncToken: auth.syncToken,
    };
    if (update && Object.prototype.hasOwnProperty.call(message || {}, "maxParticipants")) {
      body.maxParticipants = Math.max(2, Math.min(5, Number(message.maxParticipants || 5)));
    }
    const response = await fetch(VANTA_SETTINGS_API, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${auth.syncToken}`,
        "Content-Type": "application/json",
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify(body),
    });
    const result = await parseResponse(response);
    if ((response.status === 401 || response.status === 403) && retryAuth) {
      await getAuth(token, true, participantId);
      return requestRoomSettings(message, update, false);
    }
    if (!response.ok || result?.ok === false) {
      throw new Error(String(result?.error || "VANTA 방 설정을 불러오지 못했습니다."));
    }
    return {
      maxParticipants: Math.max(2, Math.min(5, Number(result.maxParticipants || 5))),
      isOwner: result.isOwner === true,
    };
  }

  async function getAuth(token, forceRefresh = false, participantId = "") {
    token = validateToken(token);
    if (authPromise && authPromiseToken === token) return authPromise;
    authPromiseToken = token;
    authPromise = (async () => {
      const stored = await readStoredAuth();
      const sameRoom = stored?.roomToken === token;
      const participantMatches = !participantId || stored?.participantId === participantId;
      const hasRequiredSyncToken = !participantId || Boolean(stored?.syncToken);
      const releaseMatches = Number(stored?.releaseVersion || 0) === RELEASE_VERSION;
      const roomAccessValid = Number(stored?.roomAccessExpiresAt || 0) - AUTH_EXPIRY_MARGIN_MS > Date.now();
      if (!forceRefresh && sameRoom && participantMatches && hasRequiredSyncToken && releaseMatches && roomAccessValid
        && stored?.idToken && Number(stored.expiresAt || 0) - AUTH_EXPIRY_MARGIN_MS > Date.now()) {
        return stored;
      }
      if (sameRoom && participantMatches && hasRequiredSyncToken && releaseMatches && roomAccessValid && stored?.refreshToken) {
        const refreshed = await refreshAuth(stored);
        if (refreshed) return refreshed;
      }
      return requestRoomAuthorization("join", token, {
        participantId: participantId || stored?.participantId || "",
      });
    })();
    try {
      return await authPromise;
    } finally {
      authPromise = null;
      authPromiseToken = "";
    }
  }

  async function requestProjectSync(action, token, participantId, payload = {}) {
    token = validateToken(token);
    participantId = String(participantId || "");
    if (participantId.length < 8 || participantId.length > 64) {
      throw new Error("VANTA Live 참여자 정보가 올바르지 않습니다.");
    }
    let auth = await getAuth(token, false, participantId);
    if (!auth?.syncToken) auth = await getAuth(token, true, participantId);
    if (!auth?.syncToken) throw new Error("VANTA 작품 동기화 권한이 없습니다.");
    const installationId = await getInstallationId();
    const response = await fetch(VANTA_SYNC_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${auth.syncToken}`,
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify({
        ...payload,
        action,
        roomId: token,
        installationId,
        participantId,
        // Some shared hosts strip Authorization before PHP. Keep the same
        // short-lived room token in the TLS-protected JSON body as a fallback.
        syncToken: auth.syncToken,
      }),
    });
    const result = await parseResponse(response);
    if (!response.ok || result?.ok === false) {
      if (response.status === 401 || response.status === 403) {
        throw new Error("VANTA 작품 동기화 권한이 만료되었습니다.");
      }
      if (response.status === 409) throw new Error("VANTA 작품이 동시에 초기화되었습니다.");
      if (response.status === 413) throw new Error("VANTA 변경 내용이 너무 큽니다.");
      if (response.status === 429) throw new Error("VANTA 변경 요청이 너무 많습니다. 잠시 후 다시 시도해 주세요.");
      throw new Error(String(result?.error || "VANTA 작품을 저장하지 못했습니다."));
    }
    return result;
  }

  function tokenFromDatabasePath(path) {
    const prefix = `${API_ROOT}/`;
    if (!String(path).startsWith(prefix)) throw new Error("VANTA 데이터 경로가 올바르지 않습니다.");
    return validateToken(String(path).slice(prefix.length).split("/")[0]);
  }

  async function databaseRequest(path, options = {}, retryAuth = true) {
    const token = tokenFromDatabasePath(path);
    const auth = await getAuth(token);
    const method = String(options.method || "GET").toUpperCase();
    const query = new URLSearchParams({ auth: auth.idToken });
    const isConditionalWrite = Object.keys(options.headers || {})
      .some((name) => ["if-match", "if-none-match"].includes(name.toLowerCase()));
    // Firebase rejects print=silent when a request also uses If-Match/If-None-Match.
    // Keep response suppression for presence writes, but not for conditional
    // project snapshot transaction that protects the revision from concurrent writers.
    if ((method === "PUT" || method === "PATCH") && !isConditionalWrite) query.set("print", "silent");
    const url = `${FIREBASE.databaseURL}/${encodePath(path)}.json?${query}`;
    const headers = { ...(options.headers || {}) };
    if (options.body !== undefined && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
    const response = await fetch(url, {
      method,
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    });
    if ((response.status === 401 || response.status === 403) && retryAuth) {
      await getAuth(token, true);
      return databaseRequest(path, options, false);
    }
    const payload = await parseResponse(response);
    if (!response.ok && response.status !== 412) throw firebaseError(payload, `Firebase 요청 실패 (${response.status})`);
    return { response, payload, auth };
  }

  function sessionPath(token, child = "") {
    return `${API_ROOT}/${validateToken(token)}${child ? `/${child}` : ""}`;
  }

  function normalizeInviteUrl(value) {
    let url;
    try {
      url = new URL(String(value || ""));
    } catch (_) {
      throw new Error("단축할 VANTA 링크가 올바르지 않습니다.");
    }
    if (url.origin !== "https://playentry.org" || url.pathname !== "/ws/new") {
      throw new Error("VANTA 초대 링크만 단축할 수 있습니다.");
    }
    validateToken(url.searchParams.get("vanta"));
    if (url.href.length > 2048) throw new Error("VANTA 초대 링크가 너무 깁니다.");
    return url;
  }

  function normalizeShortUrl(value) {
    let url;
    try {
      url = new URL(String(value || ""));
    } catch (_) {
      throw new Error("링클 서버가 올바르지 않은 주소를 반환했습니다.");
    }
    if (url.protocol !== "https:" || url.hostname.toLowerCase() !== "llnk.kr") {
      throw new Error("링클 서버가 올바르지 않은 주소를 반환했습니다.");
    }
    return url.href;
  }

  async function shortenInviteLink(message) {
    const sourceUrl = normalizeInviteUrl(message?.url).href;
    const token = validateToken(new URL(sourceUrl).searchParams.get("vanta"));
    const cacheKey = `${SHORT_LINK_PREFIX}${token}`;
    const saved = await chrome.storage.local.get(cacheKey);
    const cached = saved[cacheKey];
    if (cached?.sourceUrl === sourceUrl) {
      try {
        return { sourceUrl, shortUrl: normalizeShortUrl(cached.shortUrl), cached: true };
      } catch (_) {}
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch(SHORTENER_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: sourceUrl }),
        signal: controller.signal,
      });
      const payload = await parseResponse(response);
      if (!response.ok || payload?.ok === false || payload?.success === false) {
        if (response.status === 429) throw new Error("링클 단축 요청 한도에 도달했습니다. 잠시 후 다시 시도해 주세요.");
        throw new Error(String(payload?.error || payload?.message || "링클 단축링크를 만들지 못했습니다."));
      }
      const shortUrl = normalizeShortUrl(payload?.shortUrl || payload?.link?.short_url || payload?.link?.shortUrl);
      await chrome.storage.local.set({ [cacheKey]: { sourceUrl, shortUrl, createdAt: Date.now() } });
      return { sourceUrl, shortUrl, cached: false };
    } catch (error) {
      if (error?.name === "AbortError") throw new Error("링클 서버 응답 시간이 초과되었습니다.");
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  function flattenSession(token, remote) {
    const snapshot = remote?.snapshot;
    let project;
    let bundle = null;
    const syncVersion = Number(snapshot?.syncVersion || 1);
    if (syncVersion === SYNC_VERSION) {
      try {
        bundle = projectBundleFromChunks(snapshot?.chunks);
        project = VantaProjectChunks.assemble(bundle);
      } catch (_) {
        return null;
      }
    } else {
      project = decodeProject(snapshot?.project);
      if (!project) return null;
    }
    return {
      version: Number(remote.meta?.version || 1),
      syncVersion,
      token,
      createdAt: Number(remote.meta?.createdAt || 0),
      updatedAt: Number(snapshot?.updatedAt || 0),
      updatedBy: snapshot?.updatedBy || null,
      revision: Number(snapshot?.revision || 0),
      project,
      bundle,
    };
  }

  async function getSession(token) {
    token = validateToken(token);
    const [metaResult, snapshotResult] = await Promise.all([
      databaseRequest(sessionPath(token, "meta")),
      databaseRequest(sessionPath(token, "snapshot")),
    ]);
    if (!metaResult.payload && !snapshotResult.payload) return null;
    return flattenSession(token, { meta: metaResult.payload, snapshot: snapshotResult.payload });
  }

  async function getSessionRevision(token) {
    const { payload } = await databaseRequest(sessionPath(token, "snapshot/revision"));
    return Number(payload || 0);
  }

  async function createSession(message) {
    const session = message?.session;
    const token = validateToken(session?.token);
    if (!session?.project) throw new Error("세션을 만들 작품 데이터가 없습니다.");
    const participantId = String(session.updatedBy || "");
    if (!participantId) throw new Error("VANTA Live 참가자 정보가 없습니다.");
    await requestRoomAuthorization("create", token, {
      participantId,
      maxParticipants: session.maxParticipants,
    });
    return initializeChunkedSession({ token, baseRevision: 1, updatedBy: participantId, project: session.project });
  }

  async function initializeChunkedSession(message) {
    const token = validateToken(message?.token);
    if (!message?.project) throw new Error("저장할 VANTA 작품 데이터가 없습니다.");
    encodeProject(message.project);
    const bundle = VantaProjectChunks.split(message.project);
    const result = await requestProjectSync("initialize", token, message.updatedBy, {
      baseRevision: 1,
      syncVersion: SYNC_VERSION,
      chunkVersion: VantaProjectChunks.FORMAT_VERSION,
      chunks: bundle.chunks,
      updatedBy: message.updatedBy,
    });
    return {
      token,
      syncVersion: SYNC_VERSION,
      revision: Number(result.revision || 2),
      updatedAt: Number(result.updatedAt || Date.now()),
      updatedBy: message.updatedBy || null,
      changeId: String(result.changeId || ""),
    };
  }

  async function updateLegacySession(message) {
    const token = validateToken(message?.token);
    if (!message?.project) throw new Error("저장할 VANTA 작품 데이터가 없습니다.");
    const path = sessionPath(token, "snapshot");
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const currentResult = await databaseRequest(path, { headers: { "X-Firebase-ETag": "true" } });
      const current = currentResult.payload;
      const etag = currentResult.response.headers.get("ETag");
      if (!current?.project || !etag) throw new Error("VANTA 세션을 찾을 수 없습니다.");
      const stored = {
        revision: Number(current.revision || 0) + 1,
        updatedAt: Date.now(),
        updatedBy: message.updatedBy || null,
        // Entry project keys may contain Firebase-forbidden characters such as '.', '#',
        // '$', '[', ']', or '/'. Store the exact project as JSON text and decode on read.
        project: encodeProject(message.project),
      };
      const result = await databaseRequest(path, { method: "PUT", headers: { "If-Match": etag }, body: stored });
      if (result.response.status === 412) continue;
      return {
        revision: stored.revision,
        updatedAt: stored.updatedAt,
        hadConcurrentUpdate: Number(message.baseRevision || 0) < Number(current.revision || 0),
      };
    }
    throw new Error("동시에 변경된 내용이 많아 저장하지 못했습니다. 다시 시도합니다.");
  }

  async function updateChunkedSession(message) {
    const token = validateToken(message?.token);
    const updatedBy = String(message?.updatedBy || "");
    if (updatedBy.length < 8 || updatedBy.length > 64) throw new Error("VANTA Live 참여자 정보가 올바르지 않습니다.");
    const { normalized } = encodeProjectDelta(message?.delta);
    if (!Object.keys(normalized.changes).length && !normalized.removed.length) {
      return { revision: Number(message.baseRevision || 0), changed: false, hadConcurrentUpdate: false };
    }

    const result = await requestProjectSync("update", token, updatedBy, {
      baseRevision: Number(message.baseRevision || 0),
      syncVersion: SYNC_VERSION,
      updatedBy,
      delta: {
        changes: normalized.changes,
        removed: normalized.removed,
      },
    });
    return {
      revision: Number(result.revision || 0),
      changeId: String(result.changeId || ""),
      changed: true,
      confirmed: false,
      // The SSE event is authoritative because another participant may write between
      // this request and any follow-up GET. Avoid downloading the just-uploaded patch.
      hadConcurrentUpdate: false,
    };
  }

  function updateSession(message) {
    if (Number(message?.syncVersion || 1) === SYNC_VERSION || message?.delta) {
      return updateChunkedSession(message);
    }
    return updateLegacySession(message);
  }

  async function removeExpiredParticipants(token, participants, now) {
    for (const [slot, participant] of Object.entries(participants || {})) {
      if (Number(participant?.expiresAt || 0) <= now) {
        await databaseRequest(sessionPath(token, `participants/${slot}`), { method: "DELETE" });
        delete participants[slot];
      }
    }
    return participants;
  }

  async function acquireLiveUnlocked(message) {
    const { token, participantId, connectionId } = liveConnectionIdentity(message);
    const now = Date.now();
    const stored = await chrome.storage.local.get(ACTIVE_LIVE_KEY);
    const active = stored[ACTIVE_LIVE_KEY];
    if (active && Number(active.expiresAt || 0) > now && (active.token !== token || active.participantId !== participantId)) {
      throw new Error("이 확장 프로그램에서는 이미 다른 VANTA Live가 열려 있습니다.");
    }

    const auth = await getAuth(token, false, participantId);
    const roomMetaResult = await databaseRequest(sessionPath(token, "meta"));
    const roomMeta = roomMetaResult.payload && typeof roomMetaResult.payload === "object" ? roomMetaResult.payload : {};
    const maxParticipants = Math.max(2, Math.min(5, Number(roomMeta.maxParticipants || MAX_PARTICIPANTS)));
    const participantResult = await databaseRequest(sessionPath(token, "participants"));
    const participants = await removeExpiredParticipants(token, participantResult.payload || {}, now);
    let slot = Object.entries(participants).find(([, participant]) => participant?.uid === auth.uid)?.[0] || null;
    const joinedAt = Number(slot === null ? now : participants[slot]?.joinedAt || now);
    const candidateSlots = slot === null
      ? Array.from({ length: maxParticipants }, (_, index) => String(index)).filter((candidate) => !participants[candidate])
      : [slot];
    for (const candidate of candidateSlots) {
      try {
        const record = participantRecord(auth, participantId, message, joinedAt, now + LIVE_LEASE_MS);
        await databaseRequest(sessionPath(token, `participants/${candidate}`), {
          method: "PUT",
          body: record,
        });
        slot = candidate;
        participants[candidate] = record;
        break;
      } catch (error) {
        if (!String(error?.message || "").includes("규칙")) throw error;
      }
    }
    if (slot === null) throw new Error(`이 VANTA Live는 최대 ${maxParticipants}명까지 참여할 수 있습니다.`);
    await chrome.storage.local.set({
      [ACTIVE_LIVE_KEY]: { token, participantId, connectionId, uid: auth.uid, slot, expiresAt: now + LIVE_LEASE_MS },
    });
    let presence = null;
    try {
      presence = await reportUsagePresence("heartbeat", token, participantId, message?.name, true);
    } catch (error) {
      await databaseRequest(sessionPath(token, `participants/${slot}`), { method: "DELETE" }).catch(() => {});
      await chrome.storage.local.set({ [ACTIVE_LIVE_KEY]: null });
      throw error;
    }
    return {
      participantCount: Object.keys(participants).length,
      maxParticipants,
      participants: streamParticipantList(participants),
      quota: presence?.quota ? normalizeQuota(presence.quota) : null,
    };
  }

  function acquireLive(message) {
    const next = liveQueue.catch(() => {}).then(() => acquireLiveUnlocked(message));
    liveQueue = next;
    return next;
  }

  async function heartbeatLiveUnlocked(message) {
    const { token, participantId, connectionId } = liveConnectionIdentity(message);
    const stored = await chrome.storage.local.get(ACTIVE_LIVE_KEY);
    const active = stored[ACTIVE_LIVE_KEY];
    if (!active || active.token !== token || active.participantId !== participantId
      || active.connectionId !== connectionId) {
      throw new Error("VANTA Live 연결 정보가 만료되었습니다.");
    }
    if (!/^[0-4]$/.test(String(active.slot))) throw new Error("VANTA Live 참가자 자리가 만료되었습니다.");
    const now = Date.now();
    const roomMetaResult = await databaseRequest(sessionPath(token, "meta"));
    const roomMeta = roomMetaResult.payload && typeof roomMetaResult.payload === "object" ? roomMetaResult.payload : {};
    const maxParticipants = Math.max(2, Math.min(5, Number(roomMeta.maxParticipants || MAX_PARTICIPANTS)));
    await databaseRequest(sessionPath(token, `participants/${active.slot}`), {
      method: "PATCH",
      body: {
        name: displayName(message?.name),
        color: profileColor(message?.color),
        expiresAt: now + LIVE_LEASE_MS,
      },
    });
    const { payload } = await databaseRequest(sessionPath(token, "participants"));
    const participants = await removeExpiredParticipants(token, payload || {}, now);
    await chrome.storage.local.set({
      [ACTIVE_LIVE_KEY]: { ...active, expiresAt: now + LIVE_LEASE_MS },
    });
    const presence = await reportUsagePresence("heartbeat", token, participantId, message?.name);
    return {
      participantCount: Object.keys(participants).length,
      maxParticipants,
      participants: streamParticipantList(participants),
      quota: presence?.quota ? normalizeQuota(presence.quota) : null,
    };
  }

  function heartbeatLive(message) {
    const next = liveQueue.catch(() => {}).then(() => heartbeatLiveUnlocked(message));
    liveQueue = next;
    return next;
  }

  async function releaseLiveUnlocked(message) {
    const { token, participantId, connectionId } = liveConnectionIdentity(message);
    const stored = await chrome.storage.local.get(ACTIVE_LIVE_KEY);
    const active = stored[ACTIVE_LIVE_KEY];
    if (!active || active.token !== token || active.participantId !== participantId
      || active.connectionId !== connectionId) return true;
    if (/^[0-4]$/.test(String(active?.slot))) {
      await databaseRequest(sessionPath(token, `participants/${active.slot}`), { method: "DELETE" }).catch(() => {});
    }
    const participantResult = await databaseRequest(sessionPath(token, "participants")).catch(() => ({ payload: null }));
    const participants = await removeExpiredParticipants(token, participantResult.payload || {}, Date.now()).catch(() => participantResult.payload || {});
    if (Object.keys(participants || {}).length === 0) {
      await requestRoomClose(token).catch(() => {});
    }
    await reportUsagePresence("leave", token, participantId).catch(() => {});
    await chrome.storage.local.set({ [ACTIVE_LIVE_KEY]: null });
    return true;
  }

  function releaseLive(message) {
    const next = liveQueue.catch(() => {}).then(() => releaseLiveUnlocked(message));
    liveQueue = next;
    return next;
  }

  async function sendChat(message, retryAuth = true) {
    const { token, participantId } = liveIdentity(message);
    const text = String(message?.text || "").replace(/\r\n?/g, "\n").trim();
    if (!text || Array.from(text).length > CHAT_MAX_LENGTH || text.split("\n").length > 3) {
      throw new Error("채팅은 최대 100자, 3줄까지 보낼 수 있습니다.");
    }
    const installationId = await getInstallationId();
    const auth = await getAuth(token, false, participantId);
    const response = await fetch(VANTA_CHAT_API, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${auth.syncToken}`,
        "Content-Type": "application/json",
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify({ roomId: token, installationId, participantId, syncToken: auth.syncToken, text }),
    });
    const result = await parseResponse(response);
    if ((response.status === 401 || response.status === 403) && retryAuth) {
      await getAuth(token, true, participantId);
      return sendChat(message, false);
    }
    if (response.status === 429) throw new Error("채팅을 너무 빠르게 보내고 있습니다. 잠시 후 다시 보내 주세요.");
    if (!response.ok || result?.ok === false) throw new Error(String(result?.error || "채팅을 보내지 못했습니다."));
    return result;
  }

  async function updateCursor(message, retryAuth = true) {
    const { token, participantId } = liveIdentity(message);
    const installationId = await getInstallationId();
    const auth = await getAuth(token, false, participantId);
    const x = Math.max(0, Math.min(1, Number(message?.x) || 0));
    const y = Math.max(0, Math.min(1, Number(message?.y) || 0));
    const area = String(message?.area || "viewport").slice(0, 24);
    const response = await fetch(VANTA_CURSOR_API, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${auth.syncToken}`,
        "Content-Type": "application/json",
        "X-VANTA-Version": CLIENT_VERSION,
      },
      body: JSON.stringify({
        roomId: token,
        installationId,
        participantId,
        pollOnly: message?.pollOnly === true,
        sceneKey: String(message?.sceneKey || "").slice(0, 6),
        objectKey: String(message?.objectKey || "").slice(0, 6),
        blockKey: String(message?.blockKey || "").slice(0, 8),
        area,
        x,
        y,
        color: profileColor(message?.color),
        visible: message?.visible === true,
      }),
    });
    const result = await parseResponse(response);
    if ((response.status === 401 || response.status === 403) && retryAuth) {
      await getAuth(token, true, participantId);
      return updateCursor(message, false);
    }
    if (!response.ok || result?.ok === false) {
      throw new Error(String(result?.error || "포인터를 동기화하지 못했습니다."));
    }
    return Array.isArray(result?.cursors) ? result.cursors : [];
  }

  function streamDelay(milliseconds, signal) {
    return new Promise((resolve) => {
      if (signal.aborted) return resolve();
      const timeout = setTimeout(resolve, milliseconds);
      signal.addEventListener("abort", () => {
        clearTimeout(timeout);
        resolve();
      }, { once: true });
    });
  }

  async function readDatabaseStream(path, onEvent, signal) {
    const token = tokenFromDatabasePath(path);
    const auth = await getAuth(token);
    const url = `${FIREBASE.databaseURL}/${encodePath(path)}.json?auth=${encodeURIComponent(auth.idToken)}`;
    const response = await fetch(url, { headers: { Accept: "text/event-stream" }, signal });
    if (response.status === 401 || response.status === 403) {
      await getAuth(token, true);
      throw new Error("Firebase 실시간 스트림 인증을 갱신합니다.");
    }
    if (!response.ok || !response.body) {
      const payload = await parseResponse(response);
      throw firebaseError(payload, `Firebase 실시간 스트림 연결 실패 (${response.status})`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let eventName = "message";
    let dataLines = [];
    const dispatch = () => {
      if (!dataLines.length) return;
      const raw = dataLines.join("\n");
      dataLines = [];
      if (eventName === "keep-alive") return;
      if (eventName === "cancel" || eventName === "auth_revoked") throw new Error("Firebase 실시간 스트림이 종료되었습니다.");
      try {
        onEvent(eventName, JSON.parse(raw));
      } catch (error) {
        if (error instanceof SyntaxError) return;
        throw error;
      } finally {
        eventName = "message";
      }
    };

    while (!signal.aborted) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line) {
          dispatch();
        } else if (line.startsWith("event:")) {
          eventName = line.slice(6).trim();
        } else if (line.startsWith("data:")) {
          dataLines.push(line.slice(5).trimStart());
        }
      }
    }
  }

  function updateStreamTree(root, eventName, payload) {
    const segments = String(payload?.path || "/").split("/").filter(Boolean);
    if (!segments.length) {
      if (eventName === "patch") return { ...(root || {}), ...(payload?.data || {}) };
      return payload?.data && typeof payload.data === "object" ? payload.data : {};
    }
    const next = root && typeof root === "object" ? { ...root } : {};
    let node = next;
    for (const segment of segments.slice(0, -1)) {
      node[segment] = node[segment] && typeof node[segment] === "object" ? { ...node[segment] } : {};
      node = node[segment];
    }
    const leaf = segments.at(-1);
    if (payload?.data === null) delete node[leaf];
    else if (eventName === "patch") node[leaf] = { ...(node[leaf] || {}), ...(payload?.data || {}) };
    else node[leaf] = payload?.data;
    return next;
  }

  function streamParticipantList(participants) {
    const now = Date.now();
    return Object.values(participants || {})
      .filter((participant) => Number(participant?.expiresAt || 0) > now && participant?.participantId)
      .map((participant) => ({
        id: String(participant.participantId),
        name: displayName(participant.name),
        color: profileColor(participant.color),
        joinedAt: Number(participant.joinedAt || 0),
      }))
      .sort((left, right) => left.joinedAt - right.joinedAt || left.id.localeCompare(right.id));
  }

  function streamChatList(messages) {
    return Object.values(messages || {})
      .filter((message) => message && typeof message === "object" && message.id && message.participantId && message.text)
      .map((message) => ({
        id: String(message.id),
        participantId: String(message.participantId),
        name: displayName(message.name),
        text: Array.from(String(message.text)).slice(0, CHAT_MAX_LENGTH).join(""),
        at: Number(message.at || 0),
      }))
      .sort((left, right) => left.at - right.at || left.id.localeCompare(right.id))
      .slice(-3);
  }

  function startPortStream(port, message) {
    const { token, participantId } = liveIdentity(message);
    const syncVersion = Number(message?.syncVersion || 1);
    const controller = new AbortController();
    let participants = {};
    let chatMessages = {};
    let roomMeta = {};
    let latest = {};
    let lastLatestSignature = "";
    let latestEmitTimer = 0;
    let stopped = false;
    const safePost = (payload) => {
      if (stopped) return;
      try { port.postMessage(payload); } catch (_) { stopped = true; controller.abort(); }
    };
    const run = async (path, onEvent, signal = controller.signal) => {
      while (!stopped && !signal.aborted) {
        try {
          await readDatabaseStream(path, onEvent, signal);
        } catch (error) {
          if (!signal.aborted) safePost({ type: "STREAM_RECONNECTING", error: error?.message || "실시간 연결 재시도" });
        }
        if (!signal.aborted) await streamDelay(500, signal);
      }
    };
    run(sessionPath(token, "participants"), (eventName, payload) => {
      participants = updateStreamTree(participants, eventName, payload);
      safePost({ type: "PARTICIPANTS", participants: streamParticipantList(participants) });
    });
    run(sessionPath(token, "chat/messages"), (eventName, payload) => {
      chatMessages = updateStreamTree(chatMessages, eventName, payload);
      safePost({ type: "CHAT", messages: streamChatList(chatMessages) });
    });
    run(sessionPath(token, "meta"), (eventName, payload) => {
      roomMeta = updateStreamTree(roomMeta, eventName, payload);
      safePost({
        type: "ROOM_SETTINGS",
        maxParticipants: Math.max(2, Math.min(5, Number(roomMeta.maxParticipants || MAX_PARTICIPANTS))),
      });
    });
    if (syncVersion === SYNC_VERSION) {
      const emitLatest = () => {
        latestEmitTimer = 0;
        const revision = Number(latest?.revision || 0);
        const changeId = String(latest?.changeId || "");
        const signature = `${revision}:${changeId}`;
        if (!revision || !changeId || signature === lastLatestSignature) return;
        const delta = decodeProjectDelta(latest?.patch);
        if (!delta) {
          safePost({ type: "PROJECT_GAP", revision });
          return;
        }
        lastLatestSignature = signature;
        safePost({
          type: "PROJECT_DELTA",
          change: {
            revision,
            changeId,
            baseRevision: Number(latest?.baseRevision || 0),
            updatedAt: Number(latest?.updatedAt || 0),
            updatedBy: latest?.updatedBy || null,
            full: delta.full === true,
            delta: delta.full === true ? null : delta,
          },
        });
      };
      run(sessionPath(token, "snapshot/latest"), (eventName, payload) => {
        latest = updateStreamTree(latest, eventName, payload);
        clearTimeout(latestEmitTimer);
        latestEmitTimer = setTimeout(emitLatest, 0);
      });
    } else {
      run(sessionPath(token, "snapshot/revision"), (_eventName, payload) => {
        const revision = Number(payload?.data || 0);
        if (revision) safePost({ type: "REVISION", revision });
      });
    }
    safePost({ type: "STREAM_READY", participantId });
    return () => {
      stopped = true;
      clearTimeout(latestEmitTimer);
      controller.abort();
    };
  }

  function enqueueSessionUpdate(token, task) {
    const queueKey = String(token || "");
    const previous = sessionQueues.get(queueKey) || Promise.resolve();
    const next = previous.catch(() => {}).then(task);
    sessionQueues.set(queueKey, next);
    const cleanup = () => {
      if (sessionQueues.get(queueKey) === next) sessionQueues.delete(queueKey);
    };
    next.then(cleanup, cleanup);
    return next;
  }

  const MESSAGE_TYPES = new Set([
    "VANTA_CREATE_SESSION",
    "VANTA_GET_SESSION",
    "VANTA_GET_SESSION_REVISION",
    "VANTA_UPDATE_SESSION",
    "VANTA_ACQUIRE_LIVE",
    "VANTA_HEARTBEAT_LIVE",
    "VANTA_RELEASE_LIVE",
    "VANTA_SEND_CHAT",
    "VANTA_UPDATE_CURSOR",
    "VANTA_GET_QUOTA",
    "VANTA_GET_ROOM_SETTINGS",
    "VANTA_UPDATE_ROOM_SETTINGS",
    "VANTA_SHORTEN_LINK",
  ]);

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const type = message?.type;
    if (!MESSAGE_TYPES.has(type)) return;
    (async () => {
      if (type === "VANTA_CREATE_SESSION") return createSession(message);
      if (type === "VANTA_GET_SESSION") return getSession(message.token);
      if (type === "VANTA_GET_SESSION_REVISION") return getSessionRevision(message.token);
      if (type === "VANTA_UPDATE_SESSION") return enqueueSessionUpdate(message.token, () => updateSession(message));
      if (type === "VANTA_ACQUIRE_LIVE") return acquireLive(message);
      if (type === "VANTA_HEARTBEAT_LIVE") return heartbeatLive(message);
      if (type === "VANTA_RELEASE_LIVE") return releaseLive(message);
      if (type === "VANTA_SEND_CHAT") return sendChat(message);
      if (type === "VANTA_UPDATE_CURSOR") return updateCursor(message);
      if (type === "VANTA_GET_QUOTA") return getQuota();
      if (type === "VANTA_GET_ROOM_SETTINGS") return requestRoomSettings(message, false);
      if (type === "VANTA_UPDATE_ROOM_SETTINGS") return requestRoomSettings(message, true);
      if (type === "VANTA_SHORTEN_LINK") return shortenInviteLink(message);
      throw new Error("지원하지 않는 VANTA 요청입니다.");
    })()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "VANTA 처리 중 오류가 발생했습니다." }));
    return true;
  });

  chrome.runtime.onConnect?.addListener((port) => {
    if (port.name !== "vanta-realtime") return;
    let stop = null;
    port.onMessage.addListener((message) => {
      if (message?.type !== "SUBSCRIBE") return;
      stop?.();
      try {
        stop = startPortStream(port, message);
      } catch (error) {
        port.postMessage({ type: "STREAM_ERROR", error: error?.message || "실시간 연결을 시작하지 못했습니다." });
      }
    });
    port.onDisconnect.addListener(() => stop?.());
  });
})();
