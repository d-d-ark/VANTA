(() => {
  "use strict";

  if (window.__vantaContentLoaded || window.self !== window.top) return;
  window.__vantaContentLoaded = true;

  const PAGE_SOURCE = "vanta-page";
  const CONTENT_SOURCE = "vanta-content";
  const SYNC_CHECK_INTERVAL_MS = 500;
  const PROJECT_SYNC_IDLE_MS = 1800;
  const PROJECT_SYNC_MAX_WAIT_MS = 8000;
  const COMMAND_SYNC_DEBOUNCE_MS = 250;
  const REMOTE_POLL_INTERVAL_MS = 5000;
  const LIVE_HEARTBEAT_MS = 5000;
  const CHAT_MAX_LENGTH = 100;
  const CURSOR_ACTIVE_INTERVAL_MS = 25;
  const CURSOR_IDLE_INTERVAL_MS = 40;
  const CURSOR_KEEPALIVE_INTERVAL_MS = 1000;
  const CURSOR_CONTEXT_INTERVAL_MS = 200;
  const CODEBOARD_COORDINATE_RANGE = 2048;
  const MAX_PENDING_PROJECT_CHANGES = 64;
  const MAX_PENDING_PROJECT_BYTES = 4 * 1024 * 1024;
  const UI_SETTINGS_KEY = "vanta.uiSettings";
  const DEFAULT_PROFILE_COLOR = "#7351FF";
  const SAVE_WORK_NOTICE = "작업을 보관하려면 작품을 저장하세요.";

  const initialToken = new URL(location.href).searchParams.get("vanta") || "";

  const state = {
    token: initialToken,
    participantId: getParticipantId(),
    connectionId: randomToken(12),
    syncVersion: 1,
    revision: 0,
    lastProjectHash: "",
    projectBundle: null,
    editSequence: 0,
    syncedEditSequence: 0,
    lastEditAt: 0,
    unsyncedSinceAt: 0,
    editPointerActive: false,
    applyingRemote: false,
    connected: false,
    stopped: false,
    syncTimer: 0,
    commandSyncTimer: 0,
    routeTimer: 0,
    heartbeatTimer: 0,
    remotePollTimer: 0,
    streamReconnectTimer: 0,
    liveLeaseAcquired: false,
    participantCount: 1,
    maxParticipants: 5,
    participants: [],
    chatMessages: [],
    chatOpen: false,
    chatUnread: false,
    chatSendInFlight: false,
    chatCloseTimer: 0,
    chatPosition: null,
    chatDragging: false,
    lastChatSignature: "",
    profileDockOpen: false,
    cursorPoint: { area: "viewport", x: 0.5, y: 0.5, visible: false },
    cursorDirty: false,
    cursorInFlight: false,
    cursorTimer: 0,
    cursorContextTimer: 0,
    cursorLastRequestAt: 0,
    cursorLastWriteAt: 0,
    cursorAnimationFrame: 0,
    cursorContextInFlight: false,
    cursorContext: { sceneKey: "", objectKey: "" },
    remoteCursors: new Map(),
    displayName: "",
    displayNameReadAt: 0,
    anonymousMode: false,
    userColor: DEFAULT_PROFILE_COLOR,
    syncInFlight: false,
    syncGeneration: 0,
    remoteQueueRunning: false,
    pendingRemoteSession: null,
    pendingProjectChanges: [],
    pendingProjectChangeBytes: 0,
    projectChangeQueueRunning: false,
    projectChangeDrainTimer: 0,
    pendingRecoveryRevision: 0,
    pendingRecoverySession: null,
    connectionEpoch: 0,
    remoteApplyGeneration: 0,
    remoteApplyReleaseTimer: 0,
    streamPort: null,
    remotePollInFlight: false,
    remotePollGeneration: 0,
    pendingRemoteRevision: 0,
    remotePollRetryTimer: 0,
    remotePollBackoffMs: 700,
    panelCollapsed: !initialToken,
    quotaOpen: false,
    quotaLoading: false,
    quota: null,
    quotaError: "",
    quotaRequestSequence: 0,
    settingsOpen: false,
    settingsLink: "",
    settingsLinkLoading: false,
    settingsLinkError: "",
    roomSettingsLoading: false,
    roomSettingsSaving: false,
    roomOwner: false,
    requestSequence: 0,
    pendingRequests: new Map(),
  };
  const copyFeedbackTimers = new WeakMap();

  function isCurrentConnection(epoch, token) {
    return state.connected && !state.stopped && state.connectionEpoch === epoch && state.token === token;
  }

  function randomToken(byteLength = 24) {
    const bytes = crypto.getRandomValues(new Uint8Array(byteLength));
    let binary = "";
    for (const value of bytes) binary += String.fromCharCode(value);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  async function loadUiSettings() {
    try {
      const stored = await chrome.storage.local.get(UI_SETTINGS_KEY);
      const settings = stored?.[UI_SETTINGS_KEY];
      if (settings && typeof settings === "object") {
        state.maxParticipants = Math.max(2, Math.min(5, Number(settings.maxParticipants || 5)));
        state.anonymousMode = settings.anonymousMode === true;
        state.userColor = normalizeProfileColor(settings.userColor);
      }
    } catch (_) {}
  }

  function saveUiSettings() {
    return chrome.storage.local.set({
      [UI_SETTINGS_KEY]: {
        maxParticipants: state.maxParticipants,
        anonymousMode: state.anonymousMode,
        userColor: state.userColor,
      },
    }).catch(() => {});
  }

  function getParticipantId() {
    const key = "vanta.participantId";
    let value = sessionStorage.getItem(key);
    if (!value) {
      value = randomToken(9);
      sessionStorage.setItem(key, value);
    }
    return value;
  }

  function getDisplayName() {
    if (state.anonymousMode) return "익명";
    const now = Date.now();
    if (state.displayName && now - state.displayNameReadAt < 2000) return state.displayName;
    const nickname = [...document.querySelectorAll(".css-13o7eu2.eg4k6ki2")]
      .map((element) => element.textContent
        ?.replace(/[\u0000-\u001f\u007f]/g, "")
        .replace(/\s+/g, " ")
        .trim())
      .filter(Boolean)
      .at(-1)
      ?.slice(0, 20);
    state.displayNameReadAt = now;
    if (nickname) state.displayName = nickname === "기본형" ? "익명" : nickname;
    return state.displayName;
  }

  async function waitForDisplayName(timeoutMs = 15000) {
    if (state.anonymousMode) return "익명";
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      const name = getDisplayName();
      if (name) return name;
      await new Promise((resolve) => window.setTimeout(resolve, 150));
    }
    throw new Error("엔트리 닉네임을 찾을 수 없습니다.");
  }

  function isVantaWorkspace() {
    return location.pathname === "/ws/new" && Boolean(state.token);
  }

  function injectRuntime() {
    if (document.getElementById("vanta-page-runtime")) return;
    const script = document.createElement("script");
    script.id = "vanta-page-runtime";
    script.src = chrome.runtime.getURL("src/page-runtime.js");
    script.async = false;
    script.addEventListener("load", () => script.remove(), { once: true });
    script.addEventListener("error", () => script.remove(), { once: true });
    (document.head || document.documentElement).appendChild(script);
  }

  function pageRequest(type, payload, timeoutMs = 10000) {
    const requestId = `${state.participantId}:${Date.now()}:${++state.requestSequence}`;
    return new Promise((resolve, reject) => {
      const timeout = window.setTimeout(() => {
        state.pendingRequests.delete(requestId);
        reject(new Error("엔트리 편집기의 응답 시간이 초과되었습니다."));
      }, timeoutMs);
      state.pendingRequests.set(requestId, { resolve, reject, timeout });
      window.postMessage({ source: CONTENT_SOURCE, type, payload, requestId }, location.origin);
    });
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const message = event.data || {};
    if (message.source !== PAGE_SOURCE) return;
    if (message.type === "VANTA_ENTRY_CHANGED" && !message.requestId) {
      markEntryCommandChange();
      return;
    }
    if (!message.requestId) return;
    const pending = state.pendingRequests.get(message.requestId);
    if (!pending) return;
    window.clearTimeout(pending.timeout);
    state.pendingRequests.delete(message.requestId);
    if (message.ok) pending.resolve(message.result);
    else pending.reject(new Error(message.error || "엔트리 편집기 처리에 실패했습니다."));
  });

  async function waitForEntry(timeoutMs = 25000) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      try {
        const status = await pageRequest("VANTA_RUNTIME_STATUS", null, 1500);
        if (status?.ready) return status;
      } catch (_) {}
      await new Promise((resolve) => window.setTimeout(resolve, 250));
    }
    throw new Error("엔트리 편집기가 준비되지 않았습니다. 페이지를 새로고침해 주세요.");
  }

  function canonicalize(value) {
    if (Array.isArray(value)) return value.map(canonicalize);
    if (!value || typeof value !== "object") return value;
    const sorted = Object.create(null);
    for (const key of Object.keys(value).sort()) sorted[key] = canonicalize(value[key]);
    return sorted;
  }

  async function sha256(value) {
    const data = new TextEncoder().encode(JSON.stringify(canonicalize(value)));
    const digest = await crypto.subtle.digest("SHA-256", data);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async function captureStableProject(timeoutMs = 6000) {
    const startedAt = Date.now();
    let previousHash = "";
    let stableSamples = 0;
    let latestProject = null;
    let latestHash = "";

    while (Date.now() - startedAt < timeoutMs) {
      const candidate = await pageRequest("VANTA_EXPORT_PROJECT", null, 7000);
      if (candidate?.__vantaDeferred) {
        await new Promise((resolve) => window.setTimeout(resolve, 300));
        continue;
      }
      latestProject = candidate;
      latestHash = await sha256(latestProject);
      if (latestHash === previousHash) stableSamples += 1;
      else stableSamples = 0;
      if (stableSamples >= 2) return { project: latestProject, hash: latestHash };
      previousHash = latestHash;
      await new Promise((resolve) => window.setTimeout(resolve, 300));
    }
    if (!latestProject) throw new Error("엔트리 작품 상태를 안정화하지 못했습니다.");
    return { project: latestProject, hash: latestHash };
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response?.ok) {
          reject(new Error(response?.error || "VANTA 백그라운드 처리에 실패했습니다."));
          return;
        }
        resolve(response.result);
      });
    });
  }

  function getRoot() {
    return document.getElementById("vanta-root");
  }

  function isVantaUiTarget(target) {
    return Boolean(getRoot()?.contains(target) || document.getElementById("vanta-chat")?.contains(target));
  }

  const CURSOR_AREA_SELECTORS = {
    stage: [".entryEngineWorkspace_w", ".entryCanvasWorkspace"],
    scenes: [".entrySceneWorkspace", ".entrySceneListWorkspace"],
    objects: [".propertyPanel", ".entryContainerListWorkspaceWrapper", ".entryContainerWorkspace"],
    properties: [".entryVariablePanelWorkspace", ".propertyContent", "[class*='entryProperty']"],
    tabs: [".entryTabListWorkspace", ".entryPlaygroundTabWorkspace"],
    blockmenu: [".entryWorkspaceBlockMenu", ".blockMenuWrapper"],
    codeboard: [".entryWorkspaceBoard", ".entryBoardWrapper"],
    playground: [".entryPlaygroundWorkspace", ".entryPlayground"],
  };

  const CURSOR_AREA_FALLBACKS = {
    codeboard: "playground",
    blockmenu: "playground",
    tabs: "playground",
    properties: "objects",
  };

  function visibleRect(element) {
    if (!(element instanceof Element)) return null;
    const rect = element.getBoundingClientRect();
    return rect.width > 8 && rect.height > 8 ? rect : null;
  }

  function cursorAreaRect(area) {
    if (area === "viewport") return { left: 0, top: 0, width: innerWidth, height: innerHeight };
    for (const selector of CURSOR_AREA_SELECTORS[area] || []) {
      for (const element of document.querySelectorAll(selector)) {
        const rect = visibleRect(element);
        if (rect) return rect;
      }
    }
    const fallback = CURSOR_AREA_FALLBACKS[area];
    if (fallback) return cursorAreaRect(fallback);
    return { left: 0, top: 0, width: innerWidth, height: innerHeight };
  }

  function codeBoardBlockIdentity(block) {
    if (!(block instanceof Element)) return "";
    const group = block.closest(".svgBlockGroup");
    if (!(group instanceof Element)) return "";
    const roots = [...group.children].filter((element) => element.classList?.contains("block"));
    const root = roots.find((element) => element === block || element.contains(block));
    if (!root) return "";
    const blocks = [root, ...root.querySelectorAll(".block")];
    const rootIndex = roots.indexOf(root);
    const blockIndex = blocks.indexOf(block);
    return rootIndex >= 0 && blockIndex >= 0 ? `${rootIndex}:${blockIndex}` : "";
  }

  function codeBoardBlockKey(block) {
    const text = codeBoardBlockIdentity(block);
    if (!text) return "";
    let hash = 2166136261;
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function closestCodeBoardBlock(svg, blockKey, clientX, clientY) {
    const blocks = [...svg.querySelectorAll(".block[id]")]
      .filter((element) => visibleRect(element));
    if (blockKey) {
      return blocks.find((element) => codeBoardBlockKey(element) === blockKey) || null;
    }
    if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return null;
    let closest = null;
    let closestDistance = Infinity;
    for (const block of blocks) {
      const rect = block.getBoundingClientRect();
      const dx = clientX < rect.left
        ? rect.left - clientX
        : clientX > rect.right ? clientX - rect.right : 0;
      const dy = clientY < rect.top
        ? rect.top - clientY
        : clientY > rect.bottom ? clientY - rect.bottom : 0;
      const distance = dx * dx + dy * dy;
      if (distance < closestDistance) {
        closest = block;
        closestDistance = distance;
      }
    }
    return closest;
  }

  function codeBoardCoordinateSpace(blockKey = "", clientX = null, clientY = null) {
    const svg = [...document.querySelectorAll(".entryBoardWrapper .entryBoard")]
      .find((element) => visibleRect(element));
    const rect = visibleRect(svg);
    if (!rect) return null;
    const requestedBlockKey = /^[a-f0-9]{8}$/.test(String(blockKey || ""))
      ? String(blockKey)
      : "";
    const anchorBlock = closestCodeBoardBlock(svg, requestedBlockKey, clientX, clientY);
    if (requestedBlockKey && !anchorBlock) return null;
    const workspaceGroup = [...svg.children].find((element) =>
      element.querySelector?.(":scope > .svgBlockGroup")
    );
    const coordinateRoot = anchorBlock || workspaceGroup || svg;
    const screenMatrix = coordinateRoot.getScreenCTM?.();
    if (!screenMatrix || typeof screenMatrix.inverse !== "function" || typeof svg.createSVGPoint !== "function") {
      return null;
    }
    return {
      svg,
      rect,
      screenMatrix,
      blockKey: anchorBlock ? codeBoardBlockKey(anchorBlock) : "",
    };
  }

  function encodeCodeBoardCoordinate(value) {
    return 0.5 + Math.atan(value / CODEBOARD_COORDINATE_RANGE) / Math.PI;
  }

  function decodeCodeBoardCoordinate(value) {
    const normalized = Math.max(0.000001, Math.min(0.999999, Number(value) || 0.5));
    return Math.tan((normalized - 0.5) * Math.PI) * CODEBOARD_COORDINATE_RANGE;
  }

  function cursorContextKey(value) {
    const text = String(value || "");
    if (!text) return "";
    let hash = 2166136261;
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0").slice(0, 6);
  }

  function transformSvgPoint(codeBoard, matrix, x, y) {
    const point = codeBoard.svg.createSVGPoint();
    point.x = x;
    point.y = y;
    return point.matrixTransform(matrix);
  }

  function cursorCoordinateFromScreen(area, clientX, clientY, blockKey = "", clampResult = true) {
    const rect = cursorAreaRect(area);
    const codeBoard = area === "codeboard"
      ? codeBoardCoordinateSpace(blockKey, clientX, clientY)
      : null;
    if (codeBoard) {
      const local = transformSvgPoint(codeBoard, codeBoard.screenMatrix.inverse(), clientX, clientY);
      return {
        blockKey: codeBoard.blockKey,
        x: encodeCodeBoardCoordinate(local.x),
        y: encodeCodeBoardCoordinate(local.y),
      };
    }
    const x = (clientX - rect.left) / rect.width;
    const y = (clientY - rect.top) / rect.height;
    return {
      blockKey: "",
      x: clampResult ? Math.max(0, Math.min(1, x)) : x,
      y: clampResult ? Math.max(0, Math.min(1, y)) : y,
    };
  }

  async function refreshCursorContext() {
    if (!state.connected || state.stopped || state.cursorContextInFlight) return;
    state.cursorContextInFlight = true;
    const epoch = state.connectionEpoch;
    try {
      const status = await pageRequest("VANTA_RUNTIME_STATUS", null, 1500);
      if (epoch !== state.connectionEpoch || !state.connected) return;
      const next = {
        sceneKey: cursorContextKey(status?.sceneId),
        objectKey: cursorContextKey(status?.objectId),
      };
      if (next.sceneKey !== state.cursorContext.sceneKey
        || next.objectKey !== state.cursorContext.objectKey) {
        state.cursorContext = next;
        state.cursorDirty = true;
      }
    } catch (_) {
      // Context only controls remote cursor emphasis.
    } finally {
      state.cursorContextInFlight = false;
    }
  }

  function cursorAreaAt(clientX, clientY) {
    const target = document.elementFromPoint(clientX, clientY);
    for (let element = target; element instanceof Element; element = element.parentElement) {
      const classes = typeof element.className === "string"
        ? element.className
        : String(element.getAttribute?.("class") || "");
      let area = "";
      if (/entryScene/i.test(classes)) area = "scenes";
      else if (/entryTabList|entryPlaygroundTab|entryTabSelected/i.test(classes)) area = "tabs";
      else if (/entryWorkspaceBoard|entryBoardWrapper|(^|\s)entryBoard(\s|$)|svgObjectTitle|boardScrollbar/i.test(classes)) area = "codeboard";
      else if (/entryWorkspaceBlockMenu|entryCategory|blockMenu/i.test(classes)) area = "blockmenu";
      else if (/entryEngine|entryCanvas|entryMouseView/i.test(classes)) area = "stage";
      else if (/entryContainer|entryObject/i.test(classes)) area = "objects";
      else if (/entryVariablePanel|entryProperty|property(Content|Panel)/i.test(classes)) area = "properties";
      else if (/entryPlayground/i.test(classes)) area = "playground";
      if (area) {
        return { area, rect: cursorAreaRect(area) };
      }
    }
    return { area: "viewport", rect: cursorAreaRect("viewport") };
  }

  function trackLocalCursor(event) {
    if (!state.connected || state.stopped) return;
    if (isVantaUiTarget(event.target)) {
      hideLocalCursor();
      return;
    }
    const { area } = cursorAreaAt(event.clientX, event.clientY);
    const point = cursorCoordinateFromScreen(area, event.clientX, event.clientY);
    state.cursorPoint = {
      area,
      ...point,
      visible: true,
    };
    state.cursorDirty = true;
  }

  function hideLocalCursor() {
    if (!state.cursorPoint.visible) return;
    state.cursorPoint = { ...state.cursorPoint, visible: false };
    state.cursorDirty = true;
  }

  function cursorElement(cursor) {
    const element = document.createElement("div");
    element.className = "vanta-remote-cursor";
    element.dataset.participantId = cursor.participantId;
    element.style.setProperty("--vanta-cursor-color", normalizeProfileColor(cursor.color));
    element.style.setProperty("--vanta-cursor-foreground", contrastTextColor(cursor.color));
    const pointer = document.createElement("span");
    pointer.className = "vanta-remote-cursor-pointer";
    const label = document.createElement("span");
    label.className = "vanta-remote-cursor-label";
    label.textContent = String(cursor.name || "참여자").slice(0, 20);
    element.append(pointer, label);
    (document.body || document.documentElement).appendChild(element);
    return element;
  }

  function receiveRemoteCursors(cursors) {
    const now = Date.now();
    for (const cursor of Array.isArray(cursors) ? cursors : []) {
      if (!cursor?.participantId || cursor.participantId === state.participantId) continue;
      if (cursor.visible === false) {
        const hidden = state.remoteCursors.get(cursor.participantId);
        hidden?.element?.remove();
        state.remoteCursors.delete(cursor.participantId);
        continue;
      }
      const existing = state.remoteCursors.get(cursor.participantId) || {
        element: null,
        currentX: null,
        currentY: null,
        renderX: null,
        renderY: null,
      };
      const nextX = Math.max(0, Math.min(1, Number(cursor.x) || 0));
      const nextY = Math.max(0, Math.min(1, Number(cursor.y) || 0));
      const nextArea = String(cursor.area || "viewport");
      const nextBlockKey = String(cursor.blockKey || "").slice(0, 8);
      const serverAt = Number(cursor.at || 0);
      const isNewSample = !existing.serverAt || !serverAt || serverAt !== existing.serverAt;
      const coordinateSpaceChanged = Boolean(existing.area)
        && (existing.area !== nextArea || existing.blockKey !== nextBlockKey);
      const remappedCurrent = coordinateSpaceChanged && existing.currentX !== null
        ? cursorCoordinateFromScreen(
          nextArea,
          existing.currentX,
          existing.currentY,
          nextBlockKey,
          false
        )
        : null;
      existing.participantId = String(cursor.participantId);
      existing.name = String(cursor.name || "참여자").slice(0, 20);
      existing.color = normalizeProfileColor(cursor.color);
      existing.area = nextArea;
      existing.sceneKey = String(cursor.sceneKey || "").slice(0, 6);
      existing.objectKey = String(cursor.objectKey || "").slice(0, 6);
      existing.blockKey = nextBlockKey;
      if (isNewSample) {
        const sampleGap = existing.serverAt && serverAt
          ? Math.max(20, Math.min(140, serverAt - existing.serverAt))
          : 50;
        existing.renderX = remappedCurrent?.x ?? existing.renderX ?? existing.x ?? nextX;
        existing.renderY = remappedCurrent?.y ?? existing.renderY ?? existing.y ?? nextY;
        existing.motionFromX = existing.renderX;
        existing.motionFromY = existing.renderY;
        existing.motionStartedAt = now;
        existing.motionDuration = Math.max(120, Math.min(260, sampleGap * 2));
        existing.x = nextX;
        existing.y = nextY;
        existing.serverAt = serverAt;
      }
      existing.lastSeenAt = now;
      existing.element ||= cursorElement(existing);
      existing.element.style.setProperty("--vanta-cursor-color", existing.color);
      existing.element.style.setProperty("--vanta-cursor-foreground", contrastTextColor(existing.color));
      existing.element.querySelector(".vanta-remote-cursor-label").textContent = existing.name;
      state.remoteCursors.set(existing.participantId, existing);
    }
    if (!state.cursorAnimationFrame) state.cursorAnimationFrame = requestAnimationFrame(animateRemoteCursors);
  }

  function clearRemoteCursors() {
    if (state.cursorAnimationFrame) cancelAnimationFrame(state.cursorAnimationFrame);
    state.cursorAnimationFrame = 0;
    for (const cursor of state.remoteCursors.values()) cursor.element?.remove();
    state.remoteCursors.clear();
  }

  function animateRemoteCursors() {
    state.cursorAnimationFrame = 0;
    const now = Date.now();
    let keepAnimating = false;
    for (const [participantId, cursor] of state.remoteCursors) {
      if (!state.connected || now - cursor.lastSeenAt > 3200) {
        cursor.element?.remove();
        state.remoteCursors.delete(participantId);
        continue;
      }
      const rect = cursorAreaRect(cursor.area);
      const codeBoard = cursor.area === "codeboard"
        ? codeBoardCoordinateSpace(cursor.blockKey)
        : null;
      const motionProgress = Math.min(1, Math.max(0,
        (now - Number(cursor.motionStartedAt || now)) / Number(cursor.motionDuration || 1)
      ));
      cursor.renderX = Number(cursor.motionFromX ?? cursor.x)
        + (cursor.x - Number(cursor.motionFromX ?? cursor.x)) * motionProgress;
      cursor.renderY = Number(cursor.motionFromY ?? cursor.y)
        + (cursor.y - Number(cursor.motionFromY ?? cursor.y)) * motionProgress;
      const codeBoardPoint = codeBoard
        ? transformSvgPoint(
          codeBoard,
          codeBoard.screenMatrix,
          decodeCodeBoardCoordinate(cursor.renderX),
          decodeCodeBoardCoordinate(cursor.renderY)
        )
        : null;
      const targetX = codeBoardPoint?.x ?? rect.left + rect.width * cursor.renderX;
      const targetY = codeBoardPoint?.y ?? rect.top + rect.height * cursor.renderY;
      cursor.currentX = cursor.currentX === null ? targetX : cursor.currentX + (targetX - cursor.currentX) * 0.22;
      cursor.currentY = cursor.currentY === null ? targetY : cursor.currentY + (targetY - cursor.currentY) * 0.22;
      cursor.element.style.transform = `translate3d(${cursor.currentX}px, ${cursor.currentY}px, 0)`;
      const localContext = state.cursorContext;
      cursor.element.dataset.otherContext = (
        (cursor.sceneKey && localContext.sceneKey && cursor.sceneKey !== localContext.sceneKey)
        || (cursor.objectKey && localContext.objectKey && cursor.objectKey !== localContext.objectKey)
      ) ? "1" : "0";
      cursor.element.dataset.stale = now - cursor.lastSeenAt > 1800 ? "1" : "0";
      keepAnimating = true;
    }
    if (keepAnimating) state.cursorAnimationFrame = requestAnimationFrame(animateRemoteCursors);
  }

  async function flushCursor() {
    if (!state.connected || state.stopped || state.cursorInFlight) return;
    const now = Date.now();
    const elapsed = now - state.cursorLastRequestAt;
    if (!state.cursorDirty && elapsed < CURSOR_IDLE_INTERVAL_MS) return;
    if (state.cursorDirty && elapsed < CURSOR_ACTIVE_INTERVAL_MS) return;
    const shouldWrite = state.cursorDirty || now - state.cursorLastWriteAt >= CURSOR_KEEPALIVE_INTERVAL_MS;
    state.cursorDirty = false;
    state.cursorInFlight = true;
    state.cursorLastRequestAt = now;
    if (shouldWrite) state.cursorLastWriteAt = now;
    const epoch = state.connectionEpoch;
    const point = state.cursorPoint;
    try {
      const cursors = await sendRuntimeMessage({
        type: "VANTA_UPDATE_CURSOR",
        token: state.token,
        participantId: state.participantId,
        pollOnly: !shouldWrite,
        name: getDisplayName(),
        color: profileColor(),
        ...state.cursorContext,
        ...point,
      });
      if (epoch === state.connectionEpoch && state.connected) receiveRemoteCursors(cursors);
    } catch (_) {
      if (shouldWrite) state.cursorDirty = true;
      // Cursor presence is optional and must never interrupt project synchronization.
    } finally {
      state.cursorInFlight = false;
    }
  }

  function markUserEdit(event) {
    if (!state.connected || event.isTrusted === false || isVantaUiTarget(event.target)) return;
    const now = Date.now();
    if (!state.unsyncedSinceAt) state.unsyncedSinceAt = now;
    state.lastEditAt = now;
    state.editSequence += 1;
  }

  function scheduleCommandSync() {
    window.clearTimeout(state.commandSyncTimer);
    state.commandSyncTimer = window.setTimeout(() => {
      state.commandSyncTimer = 0;
      exportAndStoreIfChanged(true);
    }, COMMAND_SYNC_DEBOUNCE_MS);
  }

  function markEntryCommandChange() {
    if (!state.connected || state.applyingRemote || state.stopped) return;
    const now = Date.now();
    if (!state.unsyncedSinceAt) state.unsyncedSinceAt = now;
    state.lastEditAt = now;
    state.editSequence += 1;
    scheduleCommandSync();
  }

  function beginPointerEdit(event) {
    if (isVantaUiTarget(event.target)) return;
    state.editPointerActive = true;
    markUserEdit(event);
  }

  function continuePointerEdit(event) {
    if (!state.editPointerActive) return;
    markUserEdit(event);
  }

  function endPointerEdit(event) {
    if (!state.editPointerActive) return;
    markUserEdit(event);
    state.editPointerActive = false;
    scheduleCommandSync();
  }

  function setStatus(text, kind = "") {
    const root = getRoot();
    if (!root) return;
    const status = root.querySelector("[data-vanta-status]");
    const statusWrap = root.querySelector("[data-vanta-status-wrap]");
    const statusIcon = root.querySelector("[data-vanta-status-icon]");
    const message = String(text || "").trim();
    if (status) status.textContent = message;
    if (statusWrap) statusWrap.hidden = !message;
    if (statusIcon && message) {
      const iconName = kind === "error" ? "error" : kind === "warning" ? "warning" : kind === "working" ? "sync" : "check";
      setElementIcon(statusIcon, iconName);
    }
    root.dataset.kind = kind;
    window.requestAnimationFrame(() => updatePanelContentWidth(root));
  }

  function updatePanelContentWidth(root = getRoot()) {
    const content = root?.querySelector(".vanta-panel-content");
    if (!content) return;
    const width = Math.ceil(content.scrollWidth);
    if (width > 0) content.style.setProperty("--vanta-panel-open-width", `${width}px`);
  }

  function setBusy(busy) {
    const root = getRoot();
    if (!root) return;
    root.querySelectorAll("button").forEach((button) => { button.disabled = busy; });
    root.dataset.busy = busy ? "1" : "0";
  }

  function connectedStatus() {
    return "";
  }

  function deferredStatus(reason, direction) {
    if (reason === "function-editing") return "함수 편집 중";
    return "실행 중";
  }

  function shortErrorMessage(error, fallback = "오류") {
    const message = String(error?.message || error || "");
    if (/이미 다른 VANTA Live|하나만/.test(message)) return "다른 Live 사용 중";
    if (/최대 5명|참여.*자리/.test(message)) return "참여 인원 초과";
    if (/찾을 수 없|링크 코드|초대 링크|링크가 올바르지/.test(message)) return "링크 확인 필요";
    if (/만료/.test(message)) return "연결 만료";
    if (/함수 편집/.test(message)) return "함수 편집 중";
    if (/작품 실행|실행을 정지/.test(message)) return "실행 중";
    if (/복구 창/.test(message)) return "복구 창 확인";
    if (/링클|단축/.test(message)) return "링크 생성 실패";
    if (/채팅.*(빠르게|많)|too many|429/i.test(message)) return "잠시 후 전송";
    if (/채팅/.test(message)) return "채팅 전송 실패";
    if (/Firebase|실시간|서버|network|fetch/i.test(message)) return "연결 오류";
    if (/엔트리 편집기|작품 상태|작품 데이터/.test(message)) return "편집기 오류";
    if (/동시에 변경/.test(message)) return "잠시 후 재시도";
    return fallback;
  }

  function updateProfileDockWidth() {
    const dock = getRoot()?.querySelector("[data-vanta-profile-dock]");
    const list = dock?.querySelector("[data-vanta-profile-list]");
    if (!dock || !list) return;
    const profiles = [...list.querySelectorAll(".vanta-profile")];
    const profileWidth = profiles.reduce((total, profile) => {
      if (profile.dataset.expanded !== "1") return total + 30;
      return total + Math.max(30, Number.parseFloat(profile.style.getPropertyValue("--vanta-profile-expanded-width")) || 30);
    }, 0);
    const gapWidth = Math.max(0, profiles.length - 1) * 5;
    dock.style.setProperty("--vanta-profile-dock-width", `${Math.ceil(profileWidth + gapWidth)}px`);
  }

  function updateParticipantDisplay() {
    const area = getRoot()?.querySelector("[data-vanta-profile-area]");
    const dock = getRoot()?.querySelector("[data-vanta-profile-dock]");
    const list = dock?.querySelector("[data-vanta-profile-list]");
    const toggle = area?.querySelector("[data-vanta-profile-toggle]");
    const count = getRoot()?.querySelector("[data-vanta-participant-count]");
    if (count) count.textContent = `${Math.max(0, state.participantCount)}/${state.maxParticipants}`;
    if (!area || !dock || !list || !toggle) return;
    area.hidden = !state.connected;
    dock.dataset.open = state.profileDockOpen ? "1" : "0";
    dock.inert = !state.profileDockOpen;
    dock.setAttribute("aria-hidden", String(!state.profileDockOpen));
    toggle.setAttribute("aria-expanded", String(state.profileDockOpen));
    if (!state.connected) return;
    const active = [...state.participants]
      .filter((participant) => participant?.id)
      .sort((left, right) => {
        if (left.id === state.participantId) return -1;
        if (right.id === state.participantId) return 1;
        return Number(left.joinedAt || 0) - Number(right.joinedAt || 0);
      })
      .slice(0, state.maxParticipants);
    if (!active.some((participant) => participant.id === state.participantId)) {
      active.unshift({ id: state.participantId, name: getDisplayName(), joinedAt: 0 });
    }
    state.participantCount = active.length;
    if (count) count.textContent = `${state.participantCount}/${state.maxParticipants}`;
    const expandedId = list.querySelector("[data-expanded='1']")?.dataset.participantId || "";
    list.replaceChildren(...active.slice(0, state.maxParticipants).map((participant) => {
      const name = String(participant.name || "참여자").trim().slice(0, 20) || "참여자";
      const self = participant.id === state.participantId;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "vanta-profile";
      button.dataset.participantId = participant.id;
      button.dataset.expanded = expandedId === participant.id ? "1" : "0";
      const color = normalizeProfileColor(participant.color || profileColor());
      button.style.setProperty("--vanta-profile-color", color);
      button.style.setProperty("--vanta-profile-foreground", contrastTextColor(color));
      button.setAttribute("aria-label", `${name}${self ? ", 나" : ""}`);
      button.title = name;
      const initial = document.createElement("span");
      initial.className = "vanta-profile-initial";
      initial.textContent = Array.from(name)[0] || "?";
      const full = document.createElement("span");
      full.className = "vanta-profile-name";
      full.textContent = Array.from(name).slice(1).join("");
      const measure = document.createElement("span");
      measure.className = "vanta-profile-measure";
      measure.textContent = name;
      button.append(initial, full, measure);
      button.addEventListener("click", () => {
        const expand = button.dataset.expanded !== "1";
        list.querySelectorAll(".vanta-profile").forEach((item) => { item.dataset.expanded = "0"; });
        button.dataset.expanded = expand ? "1" : "0";
        window.requestAnimationFrame(() => window.requestAnimationFrame(updateProfileDockWidth));
      });
      return button;
    }));
    window.requestAnimationFrame(() => {
      list.querySelectorAll(".vanta-profile").forEach((button) => {
        const measure = button.querySelector(".vanta-profile-measure");
        button.style.setProperty("--vanta-profile-expanded-width", `${Math.min(180, 18 + Math.ceil(measure?.scrollWidth || 0))}px`);
      });
      updateProfileDockWidth();
      updatePanelContentWidth();
    });
  }

  function showRetry(show) {
    const retry = getRoot()?.querySelector("[data-vanta-retry]");
    if (retry) retry.hidden = !show;
  }

  function hasEntryRecoveryDialog() {
    const candidates = document.querySelectorAll("#entry_global_dialog, #entry_global_modal, [role='dialog']");
    return [...candidates].some((element) => {
      const text = String(element.textContent || "").replace(/\s+/g, " ");
      const rect = element.getBoundingClientRect();
      return rect.width > 0
        && rect.height > 0
        && text.includes("저장하지 않고 종료한 작품")
        && text.includes("작품 복구");
    });
  }

  async function waitForEntryRecoveryDialog(timeoutMs = 120000) {
    const startedAt = Date.now();
    while (hasEntryRecoveryDialog()) {
      setStatus("복구 창 확인", "warning");
      if (Date.now() - startedAt >= timeoutMs) {
        throw new Error("작품 복구 창이 열려 있어 VANTA 연결을 시작하지 못했습니다.");
      }
      await new Promise((resolve) => window.setTimeout(resolve, 300));
    }
  }

  async function copyInviteLink() {
    const url = new URL("https://playentry.org/ws/new");
    url.searchParams.set("type", "normal");
    url.searchParams.set("mode", new URL(location.href).searchParams.get("mode") || "block");
    url.searchParams.set("lang", new URL(location.href).searchParams.get("lang") || "ko");
    url.searchParams.set("vanta", state.token);
    let copiedUrl = url.toString();
    let shortened = false;
    setStatus("링크 생성…", "working");
    try {
      const result = await sendRuntimeMessage({ type: "VANTA_SHORTEN_LINK", url: copiedUrl });
      copiedUrl = result.shortUrl;
      shortened = true;
    } catch (_) {}
    try {
      await navigator.clipboard.writeText(copiedUrl);
    } catch (error) {
      console.warn("[VANTA] 링크 복사 실패", error);
      setStatus("복사 실패", "warning");
      return {
        inviteUrl: url.toString(),
        copiedUrl,
        copied: false,
        shortened,
      };
    }
    if (shortened) setStatus("", "success");
    else setStatus("원본 링크 복사됨", "warning");
    return {
      inviteUrl: url.toString(),
      copiedUrl,
      copied: true,
      shortened,
    };
  }

  async function createShare() {
    setBusy(true);
    setStatus("준비 중…", "working");
    try {
      await waitForEntry();
      const project = await pageRequest("VANTA_EXPORT_PROJECT");
      if (project?.__vantaDeferred) throw new Error("작품 실행을 정지한 뒤 공유해 주세요.");
      const token = randomToken(32);
      await sendRuntimeMessage({
        type: "VANTA_CREATE_SESSION",
        session: {
          token,
          updatedBy: state.participantId,
          project,
          maxParticipants: state.maxParticipants,
        },
      });

      state.token = token;
      const copyResult = await copyInviteLink();
      if (copyResult.copied) setStatus("", "working");
      window.setTimeout(() => location.assign(copyResult.inviteUrl), copyResult.copied ? 250 : 700);
    } catch (error) {
      console.error("[VANTA] 공유 실패", error);
      setStatus(shortErrorMessage(error, "공유 실패"), "error");
      setBusy(false);
    }
  }

  function disconnect() {
    stopSession("VANTA 연결을 종료했습니다.");
    const url = new URL(location.href);
    url.searchParams.delete("vanta");
    history.replaceState(history.state, "", url);
    state.token = "";
    renderPanel();
  }

  const ICON_PATHS = Object.freeze({
    link: "M3.9 12c0-2.3 1.8-4.1 4.1-4.1h4v2H8c-1.2 0-2.1.9-2.1 2.1S6.8 14.1 8 14.1h4v2H8c-2.3 0-4.1-1.8-4.1-4.1zM8 13v-2h8v2H8zm8-5.1h-4v2h4c1.2 0 2.1.9 2.1 2.1s-.9 2.1-2.1 2.1h-4v2h4c2.3 0 4.1-1.8 4.1-4.1S18.3 7.9 16 7.9z",
    check: "M5 12.5l4.2 4L19 7.5",
    logout: "M5 5h6V3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h6v-2H5V5zm12 2-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.59L17 17l5-5-5-5z",
    share: "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11A2.99 2.99 0 1 0 15 5c0 .24.04.47.09.7L8.04 9.81A3 3 0 1 0 9 12c0-.24-.04-.47-.09-.7l7.12 4.16c.5-.46 1.17-.75 1.97-.75a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
    sensors: "M7.76 16.24C6.67 15.15 6 13.65 6 12s.67-3.15 1.76-4.24l1.42 1.42C8.45 9.9 8 10.9 8 12s.45 2.1 1.17 2.83l-1.41 1.41zM16.24 7.76C17.33 8.85 18 10.35 18 12s-.67 3.15-1.76 4.24l-1.42-1.42C15.55 14.1 16 13.1 16 12s-.45-2.1-1.17-2.83l1.41-1.41zM12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm-7.07 7.07C2.61 18.76 1.17 15.56 1.17 12S2.61 5.24 4.93 2.93l1.42 1.42C4.39 6.31 3.17 9.01 3.17 12s1.22 5.69 3.18 7.65l-1.42 1.42zm14.14 0-1.42-1.42c1.96-1.96 3.18-4.66 3.18-7.65s-1.22-5.69-3.18-7.65l1.42-1.42c2.32 2.31 3.76 5.51 3.76 9.07s-1.44 6.76-3.76 9.07z",
    refresh: "M17.65 6.35A7.95 7.95 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z",
    group: "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5C15 14.17 10.33 13 8 13zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z",
    sync: "M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.96-.69 2.79l1.46 1.46A7.94 7.94 0 0 0 20 12c0-4.42-3.58-8-8-8zm-6 8c0-1.01.25-1.96.69-2.79L5.23 7.75A7.94 7.94 0 0 0 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3c-3.31 0-6-2.69-6-6z",
    warning: "M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
    error: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z",
    chat: "M4 4h16c1.1 0 2 .9 2 2v10c0 1.1-.9 2-2 2H8l-5 4V6c0-1.1.9-2 2-2zm2 4v2h12V8H6zm0 4v2h8v-2H6z",
    send: "M2.01 21 23 12 2.01 3 2 10l15 2-15 2z",
    cloud: "M19.35 10.04A7.49 7.49 0 0 0 12 4C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 0 0 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z",
    settings: "M19.43 12.98c.04-.32.07-.65.07-.98s-.03-.66-.08-.98l2.11-1.65a.5.5 0 0 0 .12-.64l-2-3.46a.5.5 0 0 0-.61-.22l-2.49 1a7.31 7.31 0 0 0-1.69-.98L14.5 2.42A.49.49 0 0 0 14 2h-4a.49.49 0 0 0-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1a.49.49 0 0 0-.61.22l-2 3.46a.5.5 0 0 0 .12.64l2.11 1.65c-.04.32-.08.66-.08.98s.03.66.08.98l-2.11 1.65a.5.5 0 0 0-.12.64l2 3.46c.12.22.38.31.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.04.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.58 1.69-.98l2.49 1c.23.08.49 0 .61-.22l2-3.46a.5.5 0 0 0-.12-.64l-2.11-1.65zM12 15.5A3.5 3.5 0 1 1 12 8a3.5 3.5 0 0 1 0 7.5z",
  });

  function setElementIcon(element, name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "24");
    svg.setAttribute("height", "24");
    svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", ICON_PATHS[name]);
    if (name === "check") {
      path.setAttribute("fill", "none");
      path.setAttribute("stroke", "currentColor");
      path.setAttribute("stroke-width", "2.4");
      path.setAttribute("stroke-linecap", "round");
      path.setAttribute("stroke-linejoin", "round");
    }
    svg.appendChild(path);
    element.replaceChildren(svg);
  }

  function setButtonIcon(button, name) {
    setElementIcon(button, name);
  }

  function iconButton(label, iconName, className = "") {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `vanta-icon-button ${className}`.trim();
    button.setAttribute("aria-label", label);
    button.title = label;
    setButtonIcon(button, iconName);
    return button;
  }

  function showCopyConfirmation(button) {
    window.clearTimeout(copyFeedbackTimers.get(button));
    setButtonIcon(button, "check");
    button.classList.add("is-confirmed");
    button.setAttribute("aria-label", "복사 완료");
    button.title = "복사 완료";
    const timer = window.setTimeout(() => {
      setButtonIcon(button, "link");
      button.classList.remove("is-confirmed");
      button.setAttribute("aria-label", "링크 복사");
      button.title = "링크 복사";
      copyFeedbackTimers.delete(button);
    }, 1800);
    copyFeedbackTimers.set(button, timer);
  }

  function quotaText() {
    if (state.quotaLoading) return "확인 중…";
    if (state.quotaError) return "확인 실패";
    if (!state.quota) return "Token";
    if (state.quota.paused) return "사용 정지";
    const percent = Math.max(0, Math.min(100, Number(state.quota.remainingPercent || 0)));
    const formatted = String(Math.round(percent));
    return `${state.quota.periodUnit || "주"} ${formatted}% 남음`;
  }

  function updateQuotaDisplay(root = getRoot()) {
    if (!root) return;
    const area = root.querySelector("[data-vanta-quota-area]");
    const detail = root.querySelector("[data-vanta-quota-detail]");
    const toggle = root.querySelector("[data-vanta-quota-toggle]");
    root.dataset.quotaOpen = state.quotaOpen ? "1" : "0";
    if (area) area.dataset.open = state.quotaOpen ? "1" : "0";
    if (detail) detail.textContent = quotaText();
    if (toggle) {
      toggle.setAttribute("aria-expanded", String(state.quotaOpen));
      toggle.title = state.quota ? `${state.quota.periodLabel} Token` : "Token";
    }
    const settingsQuota = root.querySelector("[data-vanta-settings-quota]");
    if (settingsQuota) settingsQuota.textContent = settingsQuotaText();
    window.requestAnimationFrame(() => {
      updatePanelContentWidth(root);
      window.setTimeout(() => updatePanelContentWidth(root), 340);
    });
  }

  async function loadQuota(root = getRoot()) {
    const sequence = ++state.quotaRequestSequence;
    state.quotaLoading = true;
    state.quotaError = "";
    updateQuotaDisplay(root);
    try {
      const quota = await sendRuntimeMessage({ type: "VANTA_GET_QUOTA" });
      if (sequence !== state.quotaRequestSequence) return;
      state.quota = quota;
    } catch (error) {
      if (sequence !== state.quotaRequestSequence) return;
      state.quotaError = shortErrorMessage(error, "Token 확인 실패");
    } finally {
      if (sequence === state.quotaRequestSequence) {
        state.quotaLoading = false;
        updateQuotaDisplay(root);
      }
    }
  }

  function toggleQuota(root = getRoot()) {
    state.quotaOpen = !state.quotaOpen;
    updateQuotaDisplay(root);
    if (state.quotaOpen) loadQuota(root);
  }

  function settingsQuotaText() {
    if (state.quotaLoading) return "확인 중";
    if (state.quotaError) return "확인 실패";
    if (!state.quota) return "—";
    if (state.quota.paused) return "사용 정지";
    return `${state.quota.periodUnit || "주"} ${Math.round(Math.max(0, Math.min(100, Number(state.quota.remainingPercent || 0))))}% 남음`;
  }

  function updateSettingsDisplay(root = getRoot()) {
    if (!root) return;
    root.dataset.settingsOpen = state.settingsOpen ? "1" : "0";
    const drawer = root.querySelector("[data-vanta-settings-drawer]");
    const toggle = root.querySelector("[data-vanta-settings-toggle]");
    const quota = root.querySelector("[data-vanta-settings-quota]");
    const link = root.querySelector("[data-vanta-settings-link]");
    const linkCopy = root.querySelector(".vanta-settings-link-copy");
    const anonymousToggle = root.querySelector("[data-vanta-anonymous-toggle]");
    const colorInput = root.querySelector("[data-vanta-color-input]");
    const colorPreview = root.querySelector("[data-vanta-color-preview]");
    if (drawer) {
      drawer.setAttribute("aria-hidden", String(!state.settingsOpen));
      drawer.inert = !state.settingsOpen;
    }
    if (toggle) {
      toggle.dataset.active = state.settingsOpen ? "1" : "0";
      toggle.setAttribute("aria-expanded", String(state.settingsOpen));
    }
    if (quota) quota.textContent = settingsQuotaText();
    if (link) {
      link.textContent = state.settingsLinkLoading
        ? "불러오는 중…"
        : state.settingsLinkError || state.settingsLink || (state.connected ? "—" : "Live 시작 후 생성");
      link.title = state.settingsLink || "";
    }
    if (linkCopy) linkCopy.disabled = !state.connected || state.settingsLinkLoading || !state.settingsLink;
    if (anonymousToggle) {
      anonymousToggle.dataset.enabled = state.anonymousMode ? "1" : "0";
      anonymousToggle.setAttribute("aria-checked", String(state.anonymousMode));
    }
    if (colorInput && document.activeElement !== colorInput) colorInput.value = state.userColor.slice(1).toUpperCase();
    if (colorPreview) colorPreview.style.setProperty("--vanta-user-color", state.userColor);
    root.querySelectorAll("[data-vanta-room-size]").forEach((button) => {
      button.dataset.selected = Number(button.dataset.vantaRoomSize) === state.maxParticipants ? "1" : "0";
      button.disabled = state.roomSettingsSaving || (state.connected && !state.roomOwner);
    });
  }

  async function loadRoomSettings() {
    if (!state.connected || !state.token || state.roomSettingsLoading) return;
    state.roomSettingsLoading = true;
    updateSettingsDisplay();
    try {
      const settings = await sendRuntimeMessage({ type: "VANTA_GET_ROOM_SETTINGS", token: state.token, participantId: state.participantId });
      state.maxParticipants = Math.max(2, Math.min(5, Number(settings.maxParticipants || 5)));
      state.roomOwner = settings.isOwner === true;
      updateParticipantDisplay();
    } catch (error) {
      setStatus(shortErrorMessage(error, "설정 확인 실패"), "warning");
    } finally {
      state.roomSettingsLoading = false;
      updateSettingsDisplay();
    }
  }

  function inviteUrl() {
    if (!state.token) return "";
    const url = new URL("https://playentry.org/ws/new");
    url.searchParams.set("type", "normal");
    url.searchParams.set("mode", new URL(location.href).searchParams.get("mode") || "block");
    url.searchParams.set("lang", new URL(location.href).searchParams.get("lang") || "ko");
    url.searchParams.set("vanta", state.token);
    return url.toString();
  }

  async function loadSettingsLink() {
    if (!state.connected || !state.token || state.settingsLinkLoading) return;
    const sourceUrl = inviteUrl();
    state.settingsLinkLoading = true;
    state.settingsLinkError = "";
    updateSettingsDisplay();
    try {
      const result = await sendRuntimeMessage({ type: "VANTA_SHORTEN_LINK", url: sourceUrl });
      state.settingsLink = String(result.shortUrl || sourceUrl);
    } catch (_) {
      state.settingsLink = sourceUrl;
      state.settingsLinkError = "";
    } finally {
      state.settingsLinkLoading = false;
      updateSettingsDisplay();
    }
  }

  async function copySettingsLink(button) {
    const value = state.settingsLink || inviteUrl();
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      showCopyConfirmation(button);
    } catch (_) {
      setStatus("복사 실패", "warning");
    }
  }

  async function setRoomSize(maxParticipants) {
    if (state.roomSettingsSaving || (state.connected && !state.roomOwner)) return;
    const next = Math.max(2, Math.min(5, Number(maxParticipants || 5)));
    if (next === state.maxParticipants) return;
    if (!state.connected) {
      state.maxParticipants = next;
      saveUiSettings();
      updateParticipantDisplay();
      updateSettingsDisplay();
      return;
    }
    state.roomSettingsSaving = true;
    updateSettingsDisplay();
    try {
      const settings = await sendRuntimeMessage({
        type: "VANTA_UPDATE_ROOM_SETTINGS",
        token: state.token,
        participantId: state.participantId,
        maxParticipants: next,
      });
      state.maxParticipants = Number(settings.maxParticipants || next);
      updateParticipantDisplay();
    } catch (error) {
      setStatus(shortErrorMessage(error, "인원 설정 실패"), "warning");
    } finally {
      state.roomSettingsSaving = false;
      updateSettingsDisplay();
    }
  }

  function refreshOwnIdentity() {
    const name = getDisplayName() || "익명";
    const color = profileColor();
    const own = { id: state.participantId, name, color, joinedAt: 0 };
    const index = state.participants.findIndex((participant) => participant?.id === state.participantId);
    if (index >= 0) state.participants[index] = { ...state.participants[index], name, color };
    else if (state.connected) state.participants.unshift(own);
    state.cursorDirty = true;
    updateParticipantDisplay();
    updateSettingsDisplay();
    if (state.connected) heartbeatLive();
  }

  function setAnonymousMode(enabled) {
    state.anonymousMode = enabled === true;
    saveUiSettings();
    refreshOwnIdentity();
  }

  function setUserColor(value) {
    const normalized = normalizeProfileColor(`#${String(value || "").replace(/[^0-9A-Fa-f]/g, "").slice(0, 6)}`);
    state.userColor = normalized;
    saveUiSettings();
    refreshOwnIdentity();
  }

  function createSettingsDrawer() {
    const drawer = document.createElement("div");
    drawer.className = "vanta-settings-drawer";
    drawer.dataset.vantaSettingsDrawer = "1";
    drawer.setAttribute("aria-hidden", String(!state.settingsOpen));
    drawer.inert = !state.settingsOpen;

    const roomRow = document.createElement("div");
    roomRow.className = "vanta-settings-row";
    const roomLabel = document.createElement("span");
    roomLabel.textContent = "최대 인원";
    const choices = document.createElement("div");
    choices.className = "vanta-room-size";
    for (let size = 2; size <= 5; size += 1) {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = String(size);
      button.dataset.vantaRoomSize = String(size);
      button.setAttribute("aria-label", `최대 ${size}명`);
      button.addEventListener("click", () => setRoomSize(size));
      choices.append(button);
    }
    roomRow.append(roomLabel, choices);

    const quotaRow = document.createElement("div");
    quotaRow.className = "vanta-settings-row";
    const quotaLabel = document.createElement("span");
    quotaLabel.textContent = "Token";
    const quotaValue = document.createElement("strong");
    quotaValue.dataset.vantaSettingsQuota = "1";
    quotaValue.textContent = settingsQuotaText();
    quotaRow.append(quotaLabel, quotaValue);

    const linkRow = document.createElement("div");
    linkRow.className = "vanta-settings-row vanta-settings-link-row";
    const linkText = document.createElement("span");
    linkText.className = "vanta-settings-link";
    linkText.dataset.vantaSettingsLink = "1";
    const linkCopy = iconButton("단축 링크 복사", "link", "vanta-settings-link-copy");
    linkCopy.addEventListener("click", () => copySettingsLink(linkCopy));
    linkRow.append(linkText, linkCopy);

    const anonymousRow = document.createElement("div");
    anonymousRow.className = "vanta-settings-row";
    const anonymousLabel = document.createElement("span");
    anonymousLabel.textContent = "익명 모드";
    const anonymousToggle = document.createElement("button");
    anonymousToggle.type = "button";
    anonymousToggle.className = "vanta-switch";
    anonymousToggle.dataset.vantaAnonymousToggle = "1";
    anonymousToggle.setAttribute("role", "switch");
    anonymousToggle.setAttribute("aria-label", "익명 모드");
    anonymousToggle.addEventListener("click", () => setAnonymousMode(!state.anonymousMode));
    anonymousToggle.append(document.createElement("span"));
    anonymousRow.append(anonymousLabel, anonymousToggle);

    const colorRow = document.createElement("label");
    colorRow.className = "vanta-settings-row vanta-color-row";
    const colorLabel = document.createElement("span");
    colorLabel.textContent = "프로필 · 포인터 색상";
    const colorControl = document.createElement("span");
    colorControl.className = "vanta-color-control";
    const colorPreview = document.createElement("span");
    colorPreview.className = "vanta-color-preview";
    colorPreview.dataset.vantaColorPreview = "1";
    const colorPrefix = document.createElement("span");
    colorPrefix.className = "vanta-color-prefix";
    colorPrefix.textContent = "#";
    const colorInput = document.createElement("input");
    colorInput.className = "vanta-color-input";
    colorInput.dataset.vantaColorInput = "1";
    colorInput.inputMode = "text";
    colorInput.maxLength = 6;
    colorInput.autocomplete = "off";
    colorInput.spellcheck = false;
    colorInput.setAttribute("aria-label", "프로필과 포인터 색상 6자리 HEX");
    colorInput.addEventListener("input", () => {
      colorInput.value = colorInput.value.replace(/[^0-9A-Fa-f]/g, "").slice(0, 6).toUpperCase();
      if (colorInput.value.length === 6) colorPreview.style.setProperty("--vanta-user-color", `#${colorInput.value}`);
    });
    const commitColor = () => {
      if (/^[0-9A-Fa-f]{6}$/.test(colorInput.value)) setUserColor(colorInput.value);
      else colorInput.value = state.userColor.slice(1).toUpperCase();
    };
    colorInput.addEventListener("change", commitColor);
    colorInput.addEventListener("blur", commitColor);
    colorInput.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        commitColor();
        colorInput.blur();
      }
    });
    colorControl.append(colorPreview, colorPrefix, colorInput);
    colorRow.append(colorLabel, colorControl);

    drawer.append(roomRow, quotaRow, linkRow, anonymousRow, colorRow);
    return drawer;
  }

  function renderPanel() {
    getRoot()?.remove();
    const root = document.createElement("section");
    root.id = "vanta-root";
    root.setAttribute("aria-label", "VANTA 공동 편집");

    root.dataset.live = isVantaWorkspace() ? "1" : "0";
    root.dataset.collapsed = state.panelCollapsed ? "1" : "0";
    root.dataset.quotaOpen = state.quotaOpen ? "1" : "0";
    root.dataset.settingsOpen = state.settingsOpen ? "1" : "0";
    const brand = document.createElement("button");
    brand.type = "button";
    brand.className = "vanta-brand";
    const brandImage = document.createElement("img");
    brandImage.src = chrome.runtime.getURL("assets/vanta.svg");
    brandImage.alt = "";
    brandImage.draggable = false;
    brand.append(brandImage);
    brand.setAttribute("aria-label", state.panelCollapsed ? "VANTA 패널 펼치기" : "VANTA 패널 접기");
    brand.setAttribute("aria-expanded", String(!state.panelCollapsed));
    brand.addEventListener("click", () => {
      state.panelCollapsed = !state.panelCollapsed;
      if (state.panelCollapsed) {
        state.profileDockOpen = false;
        state.quotaOpen = false;
        state.settingsOpen = false;
        updateQuotaDisplay(root);
        updateSettingsDisplay(root);
        updateParticipantDisplay();
      }
      if (!state.panelCollapsed) updatePanelContentWidth(root);
      root.dataset.collapsed = state.panelCollapsed ? "1" : "0";
      brand.setAttribute("aria-label", state.panelCollapsed ? "VANTA 패널 펼치기" : "VANTA 패널 접기");
      brand.setAttribute("aria-expanded", String(!state.panelCollapsed));
    });
    const status = document.createElement("span");
    status.dataset.vantaStatus = "1";

    const statusIcon = document.createElement("span");
    statusIcon.className = "vanta-status-icon";
    statusIcon.dataset.vantaStatusIcon = "1";

    const statusWrap = document.createElement("span");
    statusWrap.className = "vanta-status-wrap";
    statusWrap.dataset.vantaStatusWrap = "1";
    statusWrap.append(statusIcon, status);

    const connectionMotion = document.createElement("span");
    connectionMotion.className = "vanta-connection-motion";
    connectionMotion.setAttribute("aria-hidden", "true");
    const participantCount = document.createElement("span");
    participantCount.className = "vanta-participant-count";
    participantCount.dataset.vantaParticipantCount = "1";
    participantCount.textContent = `${state.participantCount}/${state.maxParticipants}`;
    participantCount.title = "현재 참여 인원";

    const actions = document.createElement("div");
    actions.className = "vanta-actions";
    const settings = iconButton("설정", "cloud", "vanta-settings-toggle");
    settings.dataset.vantaSettingsToggle = "1";
    settings.setAttribute("aria-expanded", String(state.settingsOpen));
    settings.addEventListener("click", () => {
      state.settingsOpen = !state.settingsOpen;
      if (state.settingsOpen) {
        loadQuota(root);
        if (state.connected) {
          loadRoomSettings();
          loadSettingsLink();
        }
      }
      updateSettingsDisplay(root);
    });
    if (isVantaWorkspace()) {
      const chat = iconButton("채팅", "chat", "vanta-chat-toggle");
      chat.dataset.vantaChatToggle = "1";
      chat.addEventListener("click", () => toggleChat());
      const copy = iconButton("링크 복사", "link");
      copy.addEventListener("click", async () => {
        copy.disabled = true;
        try {
          const result = await copyInviteLink();
          if (result.copied) showCopyConfirmation(copy);
        } catch (error) {
          setStatus(shortErrorMessage(error, "복사 실패"), "error");
        } finally {
          copy.disabled = false;
        }
      });
      const end = iconButton("연결 끝내기", "logout", "vanta-secondary");
      end.addEventListener("click", disconnect);
      const retry = iconButton("다시 연결", "refresh", "vanta-secondary");
      retry.dataset.vantaRetry = "1";
      retry.hidden = true;
      retry.addEventListener("click", () => joinSession());
      actions.append(chat, copy, settings, retry, end);
      status.textContent = "연결 중…";
      setElementIcon(statusIcon, "sync");
    } else {
      const share = iconButton("공유하기", "sensors", "vanta-share-button");
      share.addEventListener("click", createShare);
      actions.append(settings, share);
      statusWrap.hidden = true;
    }
    const panelContent = document.createElement("div");
    panelContent.className = `vanta-panel-content${isVantaWorkspace() ? "" : " vanta-share-content"}`;
    if (isVantaWorkspace()) panelContent.append(connectionMotion, participantCount);
    panelContent.append(statusWrap, actions);
    const profileArea = document.createElement("div");
    profileArea.className = "vanta-profile-area";
    profileArea.dataset.vantaProfileArea = "1";
    profileArea.hidden = !state.connected || !isVantaWorkspace();
    const profileToggle = iconButton("참여자 보기", "group", "vanta-profile-toggle");
    profileToggle.dataset.vantaProfileToggle = "1";
    profileToggle.setAttribute("aria-expanded", String(state.profileDockOpen));
    const profileDock = document.createElement("div");
    profileDock.className = "vanta-profile-dock";
    profileDock.dataset.vantaProfileDock = "1";
    profileDock.dataset.open = state.profileDockOpen ? "1" : "0";
    profileDock.inert = !state.profileDockOpen;
    profileDock.setAttribute("aria-hidden", String(!state.profileDockOpen));
    const profileList = document.createElement("div");
    profileList.className = "vanta-profile-list";
    profileList.dataset.vantaProfileList = "1";
    profileDock.append(profileList);
    profileToggle.addEventListener("click", () => {
      state.profileDockOpen = !state.profileDockOpen;
      profileDock.dataset.open = state.profileDockOpen ? "1" : "0";
      profileDock.inert = !state.profileDockOpen;
      profileDock.setAttribute("aria-hidden", String(!state.profileDockOpen));
      profileToggle.setAttribute("aria-expanded", String(state.profileDockOpen));
      if (state.profileDockOpen) window.requestAnimationFrame(updateProfileDockWidth);
    });
    profileArea.append(profileToggle, profileDock);
    const topRow = document.createElement("div");
    topRow.className = "vanta-top-row";
    topRow.append(brand, panelContent);
    root.append(topRow, createSettingsDrawer(), profileArea);
    document.getElementById("vanta-chat")?.remove();
    (document.body || document.documentElement).appendChild(root);
    if (isVantaWorkspace()) (document.body || document.documentElement).appendChild(createChatPanel());
    updateParticipantDisplay();
    renderChat();
    updateQuotaDisplay(root);
    updateSettingsDisplay(root);
    window.requestAnimationFrame(() => updatePanelContentWidth(root));
  }

  function normalizeProfileColor(value) {
    const color = String(value || "").toUpperCase();
    return /^#[0-9A-F]{6}$/.test(color) ? color : DEFAULT_PROFILE_COLOR;
  }

  function contrastTextColor(value) {
    const color = normalizeProfileColor(value).slice(1);
    const channels = [0, 2, 4].map((offset) => Number.parseInt(color.slice(offset, offset + 2), 16) / 255);
    const luminance = channels
      .map((channel) => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4)
      .reduce((total, channel, index) => total + channel * [0.2126, 0.7152, 0.0722][index], 0);
    return luminance > 0.179 ? "#111111" : "#FFFFFF";
  }

  function profileColor() {
    return normalizeProfileColor(state.userColor);
  }

  function loadChatPosition() {
    try {
      const value = JSON.parse(localStorage.getItem("vanta.chatPosition") || "null");
      if (Number.isFinite(value?.x) && Number.isFinite(value?.y)) {
        return { x: Math.max(0, Math.min(1, value.x)), y: Math.max(0, Math.min(1, value.y)) };
      }
    } catch (_) {}
    return null;
  }

  function applyChatPosition(panel) {
    const position = state.chatPosition || loadChatPosition();
    state.chatPosition = position;
    if (!position) {
      panel.dataset.positioned = "0";
      panel.style.removeProperty("left");
      panel.style.removeProperty("top");
      return;
    }
    const rect = panel.getBoundingClientRect();
    const maxLeft = Math.max(8, innerWidth - Math.max(rect.width, 280) - 8);
    const maxTop = Math.max(8, innerHeight - Math.max(rect.height, 140) - 8);
    panel.dataset.positioned = "1";
    panel.style.left = `${8 + position.x * Math.max(0, maxLeft - 8)}px`;
    panel.style.top = `${8 + position.y * Math.max(0, maxTop - 8)}px`;
  }

  function makeChatDraggable(panel, handle) {
    let drag = null;
    handle.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      const rect = panel.getBoundingClientRect();
      drag = { pointerId: event.pointerId, offsetX: event.clientX - rect.left, offsetY: event.clientY - rect.top };
      state.chatDragging = true;
      panel.dataset.dragging = "1";
      panel.dataset.positioned = "1";
      panel.style.left = `${rect.left}px`;
      panel.style.top = `${rect.top}px`;
      handle.setPointerCapture(event.pointerId);
      event.preventDefault();
    });
    handle.addEventListener("pointermove", (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const rect = panel.getBoundingClientRect();
      const left = Math.max(8, Math.min(innerWidth - rect.width - 8, event.clientX - drag.offsetX));
      const top = Math.max(8, Math.min(innerHeight - rect.height - 8, event.clientY - drag.offsetY));
      panel.style.left = `${left}px`;
      panel.style.top = `${top}px`;
    });
    const finish = (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const rect = panel.getBoundingClientRect();
      const maxLeft = Math.max(1, innerWidth - rect.width - 16);
      const maxTop = Math.max(1, innerHeight - rect.height - 16);
      state.chatPosition = {
        x: Math.max(0, Math.min(1, (rect.left - 8) / maxLeft)),
        y: Math.max(0, Math.min(1, (rect.top - 8) / maxTop)),
      };
      localStorage.setItem("vanta.chatPosition", JSON.stringify(state.chatPosition));
      state.chatDragging = false;
      panel.dataset.dragging = "0";
      drag = null;
    };
    handle.addEventListener("pointerup", finish);
    handle.addEventListener("pointercancel", finish);
    handle.addEventListener("dblclick", () => {
      state.chatPosition = null;
      localStorage.removeItem("vanta.chatPosition");
      applyChatPosition(panel);
    });
  }

  function createChatPanel() {
    const panel = document.createElement("section");
    panel.id = "vanta-chat";
    panel.hidden = !state.chatOpen;
    panel.dataset.open = state.chatOpen ? "1" : "0";
    panel.dataset.positioned = "0";
    panel.dataset.dragging = "0";
    panel.setAttribute("aria-label", "VANTA 채팅");
    const header = document.createElement("div");
    header.className = "vanta-chat-header";
    header.textContent = "채팅";
    header.title = "드래그해서 이동 · 두 번 클릭해서 위치 초기화";
    const list = document.createElement("div");
    list.className = "vanta-chat-list";
    list.dataset.vantaChatList = "1";
    list.setAttribute("aria-live", "polite");
    const empty = document.createElement("span");
    empty.className = "vanta-chat-empty";
    empty.dataset.vantaChatEmpty = "1";
    empty.textContent = "대화를 시작해 보세요";
    list.append(empty);
    const form = document.createElement("form");
    form.className = "vanta-chat-form";
    const textarea = document.createElement("textarea");
    textarea.rows = 1;
    textarea.maxLength = CHAT_MAX_LENGTH;
    textarea.placeholder = "메시지";
    textarea.setAttribute("aria-label", "채팅 메시지");
    const count = document.createElement("span");
    count.className = "vanta-chat-count";
    count.dataset.vantaChatCount = "1";
    count.hidden = true;
    const send = document.createElement("button");
    send.type = "submit";
    send.className = "vanta-chat-send";
    send.setAttribute("aria-label", "전송");
    send.title = "전송";
    setElementIcon(send, "send");
    textarea.addEventListener("input", () => {
      const length = Array.from(textarea.value).length;
      count.textContent = `${length}/${CHAT_MAX_LENGTH}`;
      count.hidden = length < 80;
    });
    textarea.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        form.requestSubmit();
      }
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      sendChatMessage(textarea, send);
    });
    form.append(textarea, count, send);
    panel.append(header, list, form);
    makeChatDraggable(panel, header);
    window.requestAnimationFrame(() => applyChatPosition(panel));
    return panel;
  }

  function toggleChat(force) {
    if (!state.connected) return;
    state.chatOpen = typeof force === "boolean" ? force : !state.chatOpen;
    if (state.chatOpen) state.chatUnread = false;
    renderChat();
    if (state.chatOpen) window.setTimeout(() => document.querySelector("#vanta-chat textarea")?.focus(), 220);
  }

  function renderChat() {
    const panel = document.getElementById("vanta-chat");
    if (!panel) return;
    const shouldOpen = state.chatOpen && state.connected;
    if (shouldOpen) {
      window.clearTimeout(state.chatCloseTimer);
      state.chatCloseTimer = 0;
      if (panel.hidden) {
        panel.dataset.open = "0";
        panel.hidden = false;
        window.requestAnimationFrame(() => {
          if (state.chatOpen && state.connected) panel.dataset.open = "1";
        });
      } else {
        panel.dataset.open = "1";
      }
    } else {
      panel.dataset.open = "0";
      if (!panel.hidden && !state.chatCloseTimer) {
        state.chatCloseTimer = window.setTimeout(() => {
          if (!state.chatOpen || !state.connected) panel.hidden = true;
          state.chatCloseTimer = 0;
        }, 320);
      }
    }
    const toggle = getRoot()?.querySelector("[data-vanta-chat-toggle]");
    if (toggle) {
      toggle.dataset.unread = state.chatUnread ? "1" : "0";
      toggle.dataset.active = state.chatOpen ? "1" : "0";
      toggle.setAttribute("aria-expanded", String(state.chatOpen));
    }
    const list = panel.querySelector("[data-vanta-chat-list]");
    if (!list) return;
    const messages = [...state.chatMessages]
      .sort((left, right) => Number(left.at || 0) - Number(right.at || 0) || String(left.id).localeCompare(String(right.id)))
      .slice(-3);
    if (!messages.length) {
      const empty = document.createElement("span");
      empty.className = "vanta-chat-empty";
      empty.textContent = "대화를 시작해 보세요";
      list.replaceChildren(empty);
      return;
    }
    list.replaceChildren(...messages.map((message) => {
      const item = document.createElement("div");
      item.className = `vanta-chat-message${message.participantId === state.participantId ? " is-mine" : ""}`;
      const name = document.createElement("span");
      name.className = "vanta-chat-name";
      name.textContent = message.participantId === state.participantId ? "나" : String(message.name || "참여자").slice(0, 20);
      const body = document.createElement("span");
      body.className = "vanta-chat-body";
      body.textContent = String(message.text || "");
      item.append(name, body);
      return item;
    }));
  }

  function receiveChatMessages(messages) {
    const normalized = Array.isArray(messages) ? messages.slice(-3) : [];
    const signature = normalized.map((message) => `${message.id}:${message.at}`).join("|");
    const newest = normalized.at(-1);
    if (state.lastChatSignature && signature !== state.lastChatSignature
      && newest?.participantId !== state.participantId && !state.chatOpen) {
      state.chatUnread = true;
    }
    state.lastChatSignature = signature;
    state.chatMessages = normalized;
    renderChat();
  }

  async function sendChatMessage(textarea, button) {
    if (state.chatSendInFlight || !state.connected) return;
    const text = String(textarea.value || "").replace(/\r\n?/g, "\n").trim();
    if (!text || Array.from(text).length > CHAT_MAX_LENGTH || text.split("\n").length > 3) return;
    state.chatSendInFlight = true;
    button.disabled = true;
    try {
      await sendRuntimeMessage({
        type: "VANTA_SEND_CHAT",
        token: state.token,
        participantId: state.participantId,
        text,
      });
      textarea.value = "";
      textarea.dispatchEvent(new Event("input"));
    } catch (error) {
      setStatus(shortErrorMessage(error, "채팅 전송 실패"), "warning");
    } finally {
      state.chatSendInFlight = false;
      button.disabled = false;
      textarea.focus();
    }
  }

  function startRealtimeStream() {
    window.clearTimeout(state.streamReconnectTimer);
    state.streamReconnectTimer = 0;
    const port = chrome.runtime.connect({ name: "vanta-realtime" });
    state.streamPort = port;
    port.onMessage.addListener((message) => {
      if (message?.type === "PARTICIPANTS") {
        state.participants = Array.isArray(message.participants) ? message.participants : [];
        updateParticipantDisplay();
      }
      if (message?.type === "CHAT") receiveChatMessages(message.messages);
      if (message?.type === "ROOM_SETTINGS") {
        state.maxParticipants = Math.max(2, Math.min(5, Number(message.maxParticipants || state.maxParticipants)));
        updateParticipantDisplay();
        updateSettingsDisplay();
      }
      if (message?.type === "REVISION") pollRemoteSession(message.revision);
      if (message?.type === "PROJECT_DELTA") enqueueProjectChange(message.change);
      if (message?.type === "PROJECT_GAP") pollRemoteSession(message.revision);
    });
    port.onDisconnect.addListener(() => {
      if (!state.connected || state.streamPort !== port) return;
      state.streamPort = null;
      state.streamReconnectTimer = window.setTimeout(startRealtimeStream, 500);
    });
    port.postMessage({
      type: "SUBSCRIBE",
      token: state.token,
      participantId: state.participantId,
      syncVersion: state.syncVersion,
    });
  }

  async function exportAndStoreIfChanged(force = false) {
    if (!state.connected || state.applyingRemote || state.syncInFlight || state.stopped || !isVantaWorkspace()) return;
    if (state.editSequence === state.syncedEditSequence) {
      state.unsyncedSinceAt = 0;
      return;
    }
    if (state.editPointerActive) return;
    const now = Date.now();
    const idleFor = now - Number(state.lastEditAt || now);
    const waitingFor = now - Number(state.unsyncedSinceAt || now);
    if (!force && idleFor < PROJECT_SYNC_IDLE_MS && waitingFor < PROJECT_SYNC_MAX_WAIT_MS) return;
    const epoch = state.connectionEpoch;
    const token = state.token;
    const editSequence = state.editSequence;
    const syncGeneration = ++state.syncGeneration;
    state.syncInFlight = true;
    try {
      const project = await pageRequest("VANTA_EXPORT_PROJECT", null, 5000);
      if (!isCurrentConnection(epoch, token)) return;
      if (project?.__vantaDeferred) {
        setStatus(deferredStatus(project.__vantaDeferred, "local"), "warning");
        return;
      }
      const hash = await sha256(project);
      if (!isCurrentConnection(epoch, token)) return;
      if (hash === state.lastProjectHash) {
        state.syncedEditSequence = Math.max(state.syncedEditSequence, editSequence);
        state.unsyncedSinceAt = state.editSequence > editSequence ? state.lastEditAt : 0;
        setStatus(connectedStatus(), "success");
        return;
      }
      let result;
      if (state.syncVersion === 2) {
        if (!state.projectBundle) throw new Error("VANTA 작품 조각을 다시 불러와야 합니다.");
        const nextBundle = VantaProjectChunks.split(project);
        const delta = VantaProjectChunks.diff(state.projectBundle, nextBundle);
        if (!delta.changedCount) {
          state.lastProjectHash = hash;
          state.syncedEditSequence = Math.max(state.syncedEditSequence, editSequence);
          state.unsyncedSinceAt = state.editSequence > editSequence ? state.lastEditAt : 0;
          setStatus(connectedStatus(), "success");
          return;
        }
        result = await sendRuntimeMessage({
          type: "VANTA_UPDATE_SESSION",
          token: state.token,
          syncVersion: state.syncVersion,
          baseRevision: state.revision,
          updatedBy: state.participantId,
          delta: { changes: delta.changes, removed: delta.removed },
        });
        if (!isCurrentConnection(epoch, token)) return;
        // The realtime event supplies the authoritative revision. Updating the local
        // bundle now lets another local edit diff against the state we just sent.
        state.projectBundle = nextBundle;
      } else {
        result = await sendRuntimeMessage({
          type: "VANTA_UPDATE_SESSION",
          token: state.token,
          baseRevision: state.revision,
          updatedBy: state.participantId,
          project,
        });
        if (!isCurrentConnection(epoch, token)) return;
        state.revision = Number(result.revision || state.revision);
      }
      state.lastProjectHash = hash;
      state.syncedEditSequence = Math.max(state.syncedEditSequence, editSequence);
      state.unsyncedSinceAt = state.editSequence > editSequence ? state.lastEditAt : 0;
      setStatus(result.hadConcurrentUpdate ? "동시 편집" : connectedStatus(), result.hadConcurrentUpdate ? "warning" : "success");
    } catch (error) {
      setStatus(shortErrorMessage(error, "저장 실패"), "error");
    } finally {
      if (state.syncGeneration === syncGeneration) state.syncInFlight = false;
      if (isCurrentConnection(epoch, token) && state.pendingProjectChanges.length) drainProjectChanges();
    }
  }

  async function applyRemoteSession(session) {
    const sessionRevision = Number(session?.revision || 0);
    if (!session?.project || sessionRevision < state.revision
      || (sessionRevision === state.revision && (state.syncVersion !== 2 || state.projectBundle))) return true;
    if (state.editSequence > state.syncedEditSequence) {
      setStatus("저장 중…", "working");
      return false;
    }
    const epoch = state.connectionEpoch;
    while (state.syncInFlight) {
      await new Promise((resolve) => window.setTimeout(resolve, 50));
      if (epoch !== state.connectionEpoch || state.stopped || !state.connected) return false;
    }
    // The revision and dirty checks must happen again after waiting. A queued newer
    // reconcile or a user input may have completed in the meantime.
    if (sessionRevision < state.revision
      || (sessionRevision === state.revision && (state.syncVersion !== 2 || state.projectBundle))) return true;
    if (state.editSequence > state.syncedEditSequence) return false;

    const applySequence = state.editSequence;
    const targetHash = await sha256(session.project);
    if (epoch !== state.connectionEpoch || state.stopped || !state.connected) return false;
    if (state.editSequence !== applySequence) return false;

    const commitRemoteState = () => {
      state.syncVersion = Number(session.syncVersion || state.syncVersion || 1);
      state.projectBundle = state.syncVersion === 2
        ? VantaProjectChunks.clone(session.bundle || VantaProjectChunks.split(session.project))
        : null;
      state.revision = Number(session.revision || 0);
    };

    // Own SSE acknowledgements often already match the local editor. Commit only the
    // authoritative revision/bundle and avoid a needless clearProject/loadProject.
    if (targetHash === state.lastProjectHash) {
      commitRemoteState();
      state.syncedEditSequence = Math.max(state.syncedEditSequence, applySequence);
      return true;
    }

    const runtimeStatus = await pageRequest("VANTA_RUNTIME_STATUS", null, 1500).catch(() => null);
    if (runtimeStatus?.interfaceEditing) {
      setStatus("편집 후 반영", "working");
      return false;
    }

    window.clearTimeout(state.remoteApplyReleaseTimer);
    state.remoteApplyReleaseTimer = 0;
    const applyGeneration = ++state.remoteApplyGeneration;
    state.applyingRemote = true;
    try {
      if (epoch !== state.connectionEpoch || state.editSequence !== applySequence) return false;
      const imported = await pageRequest("VANTA_IMPORT_PROJECT", { project: session.project, preserveInterface: true }, 15000);
      if (epoch !== state.connectionEpoch || state.stopped || !state.connected) return false;
      if (imported?.applied === false) {
        setStatus(deferredStatus(imported.reason, "remote"), "warning");
        return false;
      }
      commitRemoteState();
      const stable = await captureStableProject();
      if (epoch !== state.connectionEpoch || state.stopped || !state.connected) return false;
      const editedDuringApply = state.editSequence > applySequence;
      // Never mark input that happened while the imported Entry model was settling as
      // synchronized. An empty hash forces the next export to diff it against the
      // authoritative bundle instead of silently accepting the captured local state.
      state.lastProjectHash = editedDuringApply ? "" : stable.hash;
      state.syncedEditSequence = Math.max(state.syncedEditSequence, applySequence);
      state.unsyncedSinceAt = editedDuringApply ? (state.lastEditAt || Date.now()) : 0;
      if (editedDuringApply) scheduleCommandSync();
      setStatus("", "success");
      return true;
    } catch (error) {
      setStatus(shortErrorMessage(error, "동기화 실패"), "error");
      return false;
    } finally {
      window.clearTimeout(state.remoteApplyReleaseTimer);
      state.remoteApplyReleaseTimer = window.setTimeout(() => {
        if (state.remoteApplyGeneration === applyGeneration) state.applyingRemote = false;
        state.remoteApplyReleaseTimer = 0;
      }, 400);
    }
  }

  function enqueueProjectChange(change) {
    if (state.syncVersion !== 2 || !change) return;
    const revision = Number(change.revision || 0);
    const changeId = String(change.changeId || "");
    if (!revision || !changeId || revision <= state.revision) return;
    if (change.full === true) {
      requestChunkRecovery(revision);
      return;
    }
    if (state.pendingProjectChanges.some((item) => item.changeId === changeId)) return;
    let changeBytes = 0;
    try { changeBytes = JSON.stringify(change.delta).length; } catch (_) { changeBytes = MAX_PENDING_PROJECT_BYTES + 1; }
    if (state.pendingProjectChanges.length >= MAX_PENDING_PROJECT_CHANGES
      || state.pendingProjectChangeBytes + changeBytes > MAX_PENDING_PROJECT_BYTES) {
      state.pendingProjectChanges = [];
      state.pendingProjectChangeBytes = 0;
      requestChunkRecovery(revision);
      return;
    }
    state.pendingProjectChanges.push({ ...change, revision, changeId, changeBytes });
    state.pendingProjectChangeBytes += changeBytes;
    state.pendingProjectChanges.sort((left, right) => left.revision - right.revision);
    drainProjectChanges();
  }

  function scheduleProjectChangeDrain(delay = 500) {
    if (state.stopped || !state.connected) return;
    window.clearTimeout(state.projectChangeDrainTimer);
    state.projectChangeDrainTimer = window.setTimeout(() => {
      state.projectChangeDrainTimer = 0;
      if (state.pendingRecoveryRevision || state.pendingProjectChanges.length || !state.projectBundle) drainProjectChanges();
    }, delay);
  }

  function requestChunkRecovery(targetRevision = 0) {
    state.pendingRecoveryRevision = Math.max(state.pendingRecoveryRevision, Number(targetRevision || 0));
    scheduleProjectChangeDrain(0);
  }

  async function drainProjectChanges() {
    if (state.projectChangeQueueRunning || state.syncVersion !== 2
      || (!state.pendingRecoveryRevision && state.projectBundle && !state.pendingProjectChanges.length)) return;
    if (state.syncInFlight || state.editSequence > state.syncedEditSequence) {
      scheduleProjectChangeDrain();
      return;
    }
    state.projectChangeQueueRunning = true;
    let retry = false;
    try {
      const epoch = state.connectionEpoch;
      if (state.pendingRecoveryRevision || !state.projectBundle) {
        const targetRevision = Math.max(
          state.pendingRecoveryRevision,
          Number(state.pendingProjectChanges.at(-1)?.revision || 0),
        );
        if (!state.pendingRecoverySession
          || Number(state.pendingRecoverySession.revision || 0) < targetRevision) {
          const session = await sendRuntimeMessage({ type: "VANTA_GET_SESSION", token: state.token });
          if (epoch !== state.connectionEpoch || state.stopped || !state.connected) return;
          if (!session?.project || Number(session.syncVersion || 1) !== 2) {
            throw new Error("VANTA 작품 조각을 복구하지 못했습니다.");
          }
          state.pendingRecoverySession = session;
        }
        const recovery = state.pendingRecoverySession;
        const applied = await applyRemoteSession(recovery);
        if (!applied) {
          retry = true;
          return;
        }
        state.pendingRecoveryRevision = Number(recovery.revision || 0) >= state.pendingRecoveryRevision
          ? 0
          : state.pendingRecoveryRevision;
        state.pendingRecoverySession = null;
        state.pendingProjectChanges = state.pendingProjectChanges
          .filter((change) => Number(change.revision || 0) > state.revision);
        state.pendingProjectChangeBytes = state.pendingProjectChanges
          .reduce((total, change) => total + Number(change.changeBytes || 0), 0);
        return;
      }

      let bundle = VantaProjectChunks.clone(state.projectBundle);
      let revision = state.revision;
      let consumed = 0;
      for (const change of state.pendingProjectChanges) {
        if (change.revision <= revision) {
          consumed += 1;
          continue;
        }
        if (change.revision !== revision + 1 || !change.delta) {
          state.pendingRecoveryRevision = Math.max(state.pendingRecoveryRevision, change.revision);
          retry = true;
          return;
        }
        try {
          bundle = VantaProjectChunks.apply(bundle, change.delta);
        } catch (_) {
          state.pendingRecoveryRevision = Math.max(state.pendingRecoveryRevision, change.revision);
          retry = true;
          return;
        }
        revision = change.revision;
        consumed += 1;
      }

      const project = VantaProjectChunks.assemble(bundle);
      const applied = await applyRemoteSession({
        project,
        bundle,
        revision,
        syncVersion: 2,
      });
      if (!applied) {
        retry = true;
        return;
      }
      const removedChanges = state.pendingProjectChanges.splice(0, consumed);
      state.pendingProjectChangeBytes = Math.max(0, state.pendingProjectChangeBytes
        - removedChanges.reduce((total, change) => total + Number(change.changeBytes || 0), 0));
      setStatus(connectedStatus(), "success");
    } catch (error) {
      setStatus(shortErrorMessage(error, "동기화 실패"), "error");
      retry = true;
    } finally {
      state.projectChangeQueueRunning = false;
      if (retry) scheduleProjectChangeDrain(700);
      else if (state.pendingRecoveryRevision || state.pendingProjectChanges.length) scheduleProjectChangeDrain(0);
    }
  }

  function enqueueRemoteSession(session) {
    if (!session?.project || Number(session.revision || 0) <= state.revision) return;
    if (!state.pendingRemoteSession || Number(session.revision || 0) > Number(state.pendingRemoteSession.revision || 0)) {
      state.pendingRemoteSession = session;
    }
    if (state.remoteQueueRunning) return;

    state.remoteQueueRunning = true;
    (async () => {
      try {
        while (state.pendingRemoteSession) {
          const next = state.pendingRemoteSession;
          state.pendingRemoteSession = null;
          if (Number(next.revision || 0) > state.revision) {
            const applied = await applyRemoteSession(next);
            if (!applied) {
              state.pendingRemoteSession = next;
              break;
            }
          }
        }
      } finally {
        state.remoteQueueRunning = false;
        if (state.pendingRemoteSession) {
          const pending = state.pendingRemoteSession;
          window.setTimeout(() => enqueueRemoteSession(pending), 700);
        }
      }
    })();
  }

  function scheduleRemotePollRetry(delay = state.remotePollBackoffMs) {
    if (state.stopped || !state.connected || state.remotePollRetryTimer) return;
    state.remotePollRetryTimer = window.setTimeout(() => {
      state.remotePollRetryTimer = 0;
      pollRemoteSession();
    }, Math.max(0, delay));
  }

  async function pollRemoteSession(announcedRevision = 0) {
    if (!state.connected || !state.token || state.stopped) return;
    const epoch = state.connectionEpoch;
    const token = state.token;
    state.pendingRemoteRevision = Math.max(state.pendingRemoteRevision, Number(announcedRevision || 0));
    if (state.remotePollInFlight) return;
    const pollGeneration = ++state.remotePollGeneration;
    state.remotePollInFlight = true;
    try {
      const revision = state.pendingRemoteRevision || await sendRuntimeMessage({ type: "VANTA_GET_SESSION_REVISION", token: state.token });
      if (!isCurrentConnection(epoch, token)) return;
      state.pendingRemoteRevision = 0;
      if (Number(revision || 0) <= state.revision) return;
      state.remotePollBackoffMs = 700;
      if (state.syncVersion === 2) {
        requestChunkRecovery(revision);
        return;
      }
      const session = await sendRuntimeMessage({ type: "VANTA_GET_SESSION", token: state.token });
      if (!isCurrentConnection(epoch, token)) return;
      if (session?.updatedBy !== state.participantId) enqueueRemoteSession(session);
      state.remotePollBackoffMs = 700;
    } catch (error) {
      if (!isCurrentConnection(epoch, token)) return;
      setStatus(shortErrorMessage(error, "연결 확인 중…"), "warning");
      scheduleRemotePollRetry();
      state.remotePollBackoffMs = Math.min(10000, Math.round(state.remotePollBackoffMs * 1.8));
    } finally {
      if (state.remotePollGeneration === pollGeneration) state.remotePollInFlight = false;
      if (isCurrentConnection(epoch, token) && state.pendingRemoteRevision > state.revision) {
        scheduleRemotePollRetry(100);
      }
    }
  }

  async function joinSession() {
    const joinEpoch = ++state.connectionEpoch;
    state.stopped = false;
    setBusy(true);
    showRetry(false);
    setStatus("불러오는 중…", "working");
    try {
      const displayName = await waitForDisplayName();
      if (joinEpoch !== state.connectionEpoch) return;
      const live = await sendRuntimeMessage({
        type: "VANTA_ACQUIRE_LIVE",
        token: state.token,
        participantId: state.participantId,
        connectionId: state.connectionId,
        name: displayName,
        color: profileColor(),
      });
      state.liveLeaseAcquired = true;
      if (joinEpoch !== state.connectionEpoch) {
        releaseLive();
        return;
      }
      state.participantCount = Number(live.participantCount || 1);
      state.maxParticipants = Number(live.maxParticipants || 5);
      state.participants = Array.isArray(live.participants) ? live.participants : [];
      if (live.quota) {
        state.quota = live.quota;
        state.quotaError = "";
        updateQuotaDisplay();
      }
      const session = await sendRuntimeMessage({ type: "VANTA_GET_SESSION", token: state.token });
      if (joinEpoch !== state.connectionEpoch) return;
      if (!session?.project) throw new Error("이 브라우저에 저장된 VANTA 세션이 없습니다.");
      await waitForEntryRecoveryDialog();
      await waitForEntry();
      if (joinEpoch !== state.connectionEpoch) return;
      const imported = await pageRequest("VANTA_IMPORT_PROJECT", { project: session.project, preserveInterface: false }, 15000);
      if (joinEpoch !== state.connectionEpoch) return;
      if (imported?.applied === false) throw new Error("작품 실행을 정지한 뒤 다시 연결해 주세요.");
      state.syncVersion = Number(session.syncVersion || 1);
      state.projectBundle = state.syncVersion === 2
        ? VantaProjectChunks.clone(session.bundle || VantaProjectChunks.split(session.project))
        : null;
      state.revision = Number(session.revision || 1);
      const stable = await captureStableProject();
      if (joinEpoch !== state.connectionEpoch) return;
      state.lastProjectHash = stable.hash;
      state.syncedEditSequence = state.editSequence;
      state.lastEditAt = 0;
      state.unsyncedSinceAt = 0;
      state.connected = true;
      state.stopped = false;
      setBusy(false);
      updateParticipantDisplay();
      setStatus(connectedStatus(), "success");
      startRealtimeStream();
      state.syncTimer = window.setInterval(exportAndStoreIfChanged, SYNC_CHECK_INTERVAL_MS);
      state.remotePollTimer = window.setInterval(pollRemoteSession, REMOTE_POLL_INTERVAL_MS);
      state.routeTimer = window.setInterval(checkRoute, 500);
      state.heartbeatTimer = window.setInterval(heartbeatLive, LIVE_HEARTBEAT_MS);
      state.cursorTimer = window.setInterval(flushCursor, 25);
      state.cursorContextTimer = window.setInterval(refreshCursorContext, CURSOR_CONTEXT_INTERVAL_MS);
      refreshCursorContext();
      flushCursor();
    } catch (error) {
      setStatus(shortErrorMessage(error, "연결 실패"), "error");
      setBusy(false);
      showRetry(true);
      releaseLive();
    }
  }

  function heartbeatLive() {
    if (!state.liveLeaseAcquired || !state.token) return;
    const epoch = state.connectionEpoch;
    const token = state.token;
    sendRuntimeMessage({
      type: "VANTA_HEARTBEAT_LIVE",
      token: state.token,
      participantId: state.participantId,
      connectionId: state.connectionId,
      name: getDisplayName(),
      color: profileColor(),
    }).then((live) => {
      if (!isCurrentConnection(epoch, token)) return;
      state.participantCount = Number(live.participantCount || state.participantCount);
      state.maxParticipants = Number(live.maxParticipants || state.maxParticipants);
      if (Array.isArray(live.participants)) state.participants = live.participants;
      if (live.quota) {
        state.quota = live.quota;
        state.quotaError = "";
        updateQuotaDisplay();
      }
      updateParticipantDisplay();
    }).catch((error) => {
      if (isCurrentConnection(epoch, token)) stopSession(shortErrorMessage(error, "연결 종료"));
    });
  }

  function releaseLive() {
    if (!state.liveLeaseAcquired || !state.token) return;
    state.liveLeaseAcquired = false;
    sendRuntimeMessage({
      type: "VANTA_RELEASE_LIVE",
      token: state.token,
      participantId: state.participantId,
      connectionId: state.connectionId,
    }).catch(() => {});
  }

  function checkRoute() {
    if (state.connected && !isVantaWorkspace()) {
      stopSession("공유 종료");
    }
  }

  function stopSession(message) {
    state.connectionEpoch += 1;
    state.connected = false;
    state.stopped = true;
    window.clearInterval(state.syncTimer);
    window.clearInterval(state.routeTimer);
    window.clearInterval(state.heartbeatTimer);
    window.clearInterval(state.remotePollTimer);
    window.clearInterval(state.cursorTimer);
    window.clearInterval(state.cursorContextTimer);
    window.clearTimeout(state.streamReconnectTimer);
    window.clearTimeout(state.commandSyncTimer);
    window.clearTimeout(state.projectChangeDrainTimer);
    window.clearTimeout(state.remotePollRetryTimer);
    window.clearTimeout(state.remoteApplyReleaseTimer);
    window.clearTimeout(state.chatCloseTimer);
    state.syncTimer = 0;
    state.routeTimer = 0;
    state.heartbeatTimer = 0;
    state.remotePollTimer = 0;
    state.cursorTimer = 0;
    state.cursorContextTimer = 0;
    state.streamReconnectTimer = 0;
    state.commandSyncTimer = 0;
    state.projectChangeDrainTimer = 0;
    state.remotePollRetryTimer = 0;
    state.remoteApplyReleaseTimer = 0;
    state.chatCloseTimer = 0;
    state.pendingProjectChanges = [];
    state.pendingProjectChangeBytes = 0;
    state.projectChangeQueueRunning = false;
    state.pendingRecoveryRevision = 0;
    state.pendingRecoverySession = null;
    state.pendingRemoteRevision = 0;
    state.pendingRemoteSession = null;
    state.applyingRemote = false;
    state.remoteApplyGeneration += 1;
    state.syncInFlight = false;
    state.syncGeneration += 1;
    state.remotePollInFlight = false;
    state.remotePollGeneration += 1;
    state.editPointerActive = false;
    state.cursorPoint = { area: "viewport", x: 0.5, y: 0.5, visible: false };
    state.cursorDirty = false;
    state.cursorInFlight = false;
    state.cursorLastRequestAt = 0;
    state.cursorLastWriteAt = 0;
    state.cursorContextInFlight = false;
    state.cursorContext = { sceneKey: "", objectKey: "" };
    clearRemoteCursors();
    state.participants = [];
    state.chatMessages = [];
    state.chatOpen = false;
    state.chatUnread = false;
    state.lastChatSignature = "";
    state.profileDockOpen = false;
    state.settingsOpen = false;
    state.settingsLink = "";
    state.settingsLinkLoading = false;
    state.settingsLinkError = "";
    state.roomOwner = false;
    const streamPort = state.streamPort;
    state.streamPort = null;
    streamPort?.disconnect();
    document.getElementById("vanta-chat")?.setAttribute("hidden", "");
    updateParticipantDisplay();
    releaseLive();
    const base = String(message || "VANTA 연결이 종료되었습니다.").trim();
    setStatus(base.includes(SAVE_WORK_NOTICE) ? base : `${base} ${SAVE_WORK_NOTICE}`, "warning");
  }

  async function init() {
    if (!/^\/ws(?:\/|$)/.test(location.pathname)) return;
    injectRuntime();
    document.addEventListener("pointerdown", beginPointerEdit, true);
    document.addEventListener("pointermove", continuePointerEdit, true);
    document.addEventListener("pointermove", trackLocalCursor, true);
    document.addEventListener("pointerup", endPointerEdit, true);
    document.addEventListener("pointercancel", endPointerEdit, true);
    document.addEventListener("keydown", markUserEdit, true);
    document.addEventListener("input", markUserEdit, true);
    document.addEventListener("change", markUserEdit, true);
    document.addEventListener("mouseout", (event) => {
      if (!event.relatedTarget) hideLocalCursor();
    }, true);
    window.addEventListener("blur", hideLocalCursor);
    window.addEventListener("resize", () => {
      const panel = document.getElementById("vanta-chat");
      if (panel) applyChatPosition(panel);
    });
    await loadUiSettings();
    renderPanel();
    if (isVantaWorkspace()) joinSession();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();

  window.addEventListener("pagehide", () => stopSession("VANTA 연결이 종료되었습니다."), { once: true });
})();
