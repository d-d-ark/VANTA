(() => {
  "use strict";

  if (window.__vantaPageRuntimeLoaded) return;
  window.__vantaPageRuntimeLoaded = true;

  const CONTENT_SOURCE = "vanta-content";
  const PAGE_SOURCE = "vanta-page";
  const commandObserver = {};
  let observedDoEvent = null;
  let observedDoListener = null;
  let observedCreationEvent = null;
  let observedCreationListener = null;
  let projectImportMotionGeneration = 0;

  function notifyEntryChanged(commandType = null) {
    window.postMessage({
      source: PAGE_SOURCE,
      type: "VANTA_ENTRY_CHANGED",
      commandType: ["string", "number"].includes(typeof commandType) ? commandType : null,
    }, location.origin);
  }

  function ensureCommandObserver(entry) {
    const doEvent = entry?.commander?.doEvent;
    if (doEvent && typeof doEvent.attach === "function" && doEvent !== observedDoEvent) {
      observedDoListener?.destroy?.();
      observedDoEvent = doEvent;
      observedDoListener = doEvent.attach(commandObserver, (commandType) => notifyEntryChanged(commandType));
    }
    const creationEvent = entry?.creationChangedEvent;
    if (creationEvent && typeof creationEvent.attach === "function" && creationEvent !== observedCreationEvent) {
      observedCreationListener?.destroy?.();
      observedCreationEvent = creationEvent;
      observedCreationListener = creationEvent.attach(commandObserver, () => notifyEntryChanged());
    }
  }

  function cloneJson(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function getEntry() {
    const entry = window.Entry;
    const ready = entry
      && typeof entry.exportProject === "function"
      && typeof entry.loadProject === "function"
      && typeof entry.clearProject === "function"
      && typeof entry.container?.toJSON === "function"
      && typeof entry.container?.setObjects === "function"
      && typeof entry.scene?.toJSON === "function"
      && typeof entry.scene?.addScenes === "function"
      && typeof entry.variableContainer?.getVariableJSON === "function"
      && typeof entry.variableContainer?.setVariables === "function"
      && typeof entry.variableContainer?.setMessages === "function"
      && typeof entry.variableContainer?.setFunctions === "function"
      && typeof entry.stage?.initObjectContainers === "function";
    if (!ready) return null;
    ensureCommandObserver(entry);
    return entry;
  }

  function currentTitle() {
    const input = document.querySelector("#common_srch input[maxlength='30']");
    return input instanceof HTMLInputElement ? input.value.trim() : "";
  }

  function normalizeProject(rawProject) {
    const project = cloneJson(rawProject);
    delete project._id;
    delete project.interface;
    return project;
  }

  function setProjectTitle(title) {
    const input = document.querySelector("#common_srch input[maxlength='30']");
    if (!title || !(input instanceof HTMLInputElement)) return;
    const value = String(title).slice(0, 30);
    const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    if (nativeSetter) nativeSetter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function isEngineActive(entry) {
    const engineState = typeof entry.engine?.state === "string" ? entry.engine.state : "";
    if (engineState) return engineState !== "stop";
    if (typeof entry.engine?.isState === "function") {
      if (entry.engine.isState("run") || entry.engine.isState("pause") || entry.engine.isState("stopping")) return true;
    }
    const stopButton = document.querySelector(".entryStopButtonWorkspace_w");
    const startButton = document.querySelector(".entryRunButtonWorkspace_w");
    const visible = (element) => {
      if (!(element instanceof HTMLElement) || element.classList.contains("entryRemove")) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    if (visible(startButton)) return false;
    if (visible(stopButton)) return true;
    return false;
  }

  function isFunctionEditing(entry) {
    return entry.Func?.isEdit === true;
  }

  function selectedEditorContext(entry) {
    const object = entry?.container?.selectedObject || entry?.playground?.object || null;
    return {
      sceneId: entry?.scene?.selectedScene?.id || null,
      objectId: object?.id || null,
    };
  }

  function isInterfaceEditing(entry = window.Entry) {
    const variableContainer = entry?.variableContainer;
    if ([
      variableContainer?.variableAddPanel,
      variableContainer?.listAddPanel,
      variableContainer?.messageAddPanel,
    ].some((panel) => panel?.isOpen === true)) return true;
    if (document.querySelector(
      ".entryVariableAddSpaceWorkspace:not(.off), .message_inpt:not(.off)"
    )) return true;
    const active = document.activeElement;
    if (!(active instanceof HTMLElement) || active === document.body) return false;
    if (active.closest?.("#vanta-root, #vanta-chat")) return false;
    return active.matches("input, textarea, select, [contenteditable='true']");
  }

  function captureEditorLocation(entry) {
    const object = entry.container?.selectedObject || entry.playground?.object || null;
    const scrollSelectors = [
      ".entrySceneListWorkspace",
      ".entryObjectListWorkspace",
      ".entryPlaygroundCodeWorkspace",
      ".entryPlaygroundPictureWorkspace",
      ".entryPlaygroundSoundWorkspace",
      ".entryVariablePanelWorkspace",
    ];
    return {
      sceneId: entry.scene?.selectedScene?.id || null,
      objectId: object?.id || null,
      viewMode: entry.playground?.getViewMode?.() || entry.playground?.viewMode_ || "code",
      workspaceMode: entry.getMainWS?.()?.getMode?.() ?? null,
      pictureId: object?.selectedPicture?.id || null,
      soundId: object?.selectedSound?.id || null,
      scroll: scrollSelectors.map((selector) => {
        const element = document.querySelector(selector);
        return element ? { selector, left: element.scrollLeft, top: element.scrollTop } : null;
      }).filter(Boolean),
    };
  }

  function restoreEditorLocation(entry, location) {
    if (!location) return;
    try {
      const scene = location.sceneId && entry.scene?.getSceneById?.(location.sceneId);
      if (scene) entry.scene.selectScene(scene);
      const object = location.objectId && entry.container?.getObject?.(location.objectId);
      if (object) entry.container.selectObject(object.id, true);
      if (object && ["code", "picture", "text", "sound", "variable"].includes(location.viewMode)) {
        entry.playground?.changeViewMode?.(location.viewMode);
      }
      if (object && location.pictureId && object.getPicture?.(location.pictureId)) {
        entry.container.selectPicture(location.pictureId, object.id);
      }
      if (object && location.soundId && object.getSound?.(location.soundId)) {
        entry.container.selectSound(location.soundId, object.id);
      }
      for (const saved of location.scroll || []) {
        const element = document.querySelector(saved.selector);
        if (element) {
          element.scrollLeft = saved.left;
          element.scrollTop = saved.top;
        }
      }
    } catch (_) {
      // A remotely deleted scene/object cannot be restored; Entry's first valid item stays selected.
    }
  }

  function resetFunctionMenuCache(entry) {
    if (!entry?.Func || isFunctionEditing(entry)) return;
    if (typeof entry.Func.reset === "function") entry.Func.reset();
    else entry.Func.menuCode = undefined;
    const workspace = typeof entry.getMainWS === "function" ? entry.getMainWS() : entry.mainWorkspace;
    const blockMenu = typeof workspace?.getBlockMenu === "function" ? workspace.getBlockMenu() : workspace?.blockMenu;
    blockMenu?.deleteRendered?.("variable");
  }

  function beginProjectImportMotionGuard() {
    const root = document.documentElement;
    const generation = ++projectImportMotionGeneration;
    root?.classList?.add?.("vanta-importing-project");
    let released = false;
    return () => {
      if (released) return;
      released = true;
      const remove = () => {
        if (generation === projectImportMotionGeneration) root?.classList?.remove?.("vanta-importing-project");
      };
      const settle = () => {
        if (typeof window.setTimeout === "function") window.setTimeout(remove, 160);
        else remove();
      };
      if (typeof window.requestAnimationFrame === "function") {
        window.requestAnimationFrame(() => window.requestAnimationFrame(settle));
      } else {
        settle();
      }
    };
  }

  function exportProject() {
    const entry = getEntry();
    if (!entry) throw new Error("엔트리 편집기가 아직 준비되지 않았습니다.");
    if (isEngineActive(entry)) {
      return { __vantaDeferred: "engine-running" };
    }
    if (isFunctionEditing(entry)) {
      return { __vantaDeferred: "function-editing" };
    }
    const project = normalizeProject(entry.exportProject({}));
    if (!project?.objects || !project?.scenes) throw new Error("엔트리 작품 상태를 읽지 못했습니다.");
    if (currentTitle() && !project.name) project.name = currentTitle();
    return cloneJson(project);
  }

  function importProject(rawProject, preserveInterface) {
    const entry = getEntry();
    if (!entry) throw new Error("엔트리 편집기가 아직 준비되지 않았습니다.");
    if (isEngineActive(entry)) {
      return { applied: false, reason: "engine-running" };
    }
    if (isFunctionEditing(entry)) {
      return { applied: false, reason: "function-editing" };
    }
    if (!rawProject || !Array.isArray(rawProject.objects) || !Array.isArray(rawProject.scenes)) {
      throw new Error("올바른 엔트리 작품 데이터가 아닙니다.");
    }

    const project = normalizeProject(rawProject);
    const backupProject = normalizeProject(entry.exportProject({}));
    const localInterface = preserveInterface && typeof entry.captureInterfaceState === "function"
      ? cloneJson(entry.captureInterfaceState())
      : null;
    const editorLocation = preserveInterface ? captureEditorLocation(entry) : null;
    const releaseMotionGuard = beginProjectImportMotionGuard();
    try {
      // Entry caches the function parameter palette separately from project data. If a
      // remote load keeps that cache, old and new argument blocks are rendered together.
      resetFunctionMenuCache(entry);
      try {
        entry.clearProject();
        entry.loadProject(project);
      } catch (error) {
        try {
          entry.clearProject();
          entry.loadProject(backupProject);
        } catch (_) {
          // Preserve the original load error; a second failure means Entry itself can no
          // longer restore the previously exported model safely.
        }
        resetFunctionMenuCache(entry);
        throw error;
      }
      resetFunctionMenuCache(entry);
      if (localInterface && typeof entry.loadInterfaceState === "function") {
        entry.loadInterfaceState(localInterface);
      }
      if (editorLocation) {
        restoreEditorLocation(entry, editorLocation);
        window.setTimeout(() => restoreEditorLocation(entry, editorLocation), 0);
        window.setTimeout(() => restoreEditorLocation(entry, editorLocation), 120);
      }

      setProjectTitle(project.name);
      return { applied: true };
    } finally {
      releaseMotionGuard();
    }
  }

  function respond(requestId, ok, result, error) {
    window.postMessage({
      source: PAGE_SOURCE,
      requestId,
      ok,
      result,
      error,
    }, location.origin);
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const message = event.data || {};
    if (message.source !== CONTENT_SOURCE || !message.requestId) return;

    try {
      if (message.type === "VANTA_RUNTIME_STATUS") {
        const entry = getEntry();
        respond(message.requestId, true, {
          ready: Boolean(entry),
          projectId: window.Entry?.projectId || null,
          interfaceEditing: isInterfaceEditing(entry),
          ...selectedEditorContext(entry),
        });
        return;
      }
      if (message.type === "VANTA_EXPORT_PROJECT") {
        respond(message.requestId, true, exportProject());
        return;
      }
      if (message.type === "VANTA_IMPORT_PROJECT") {
        respond(message.requestId, true, importProject(message.payload?.project, message.payload?.preserveInterface === true));
        return;
      }
      respond(message.requestId, false, null, "지원하지 않는 VANTA 요청입니다.");
    } catch (error) {
      respond(message.requestId, false, null, error?.message || "엔트리 작품 처리 중 오류가 발생했습니다.");
    }
  });

  window.postMessage({ source: PAGE_SOURCE, type: "VANTA_RUNTIME_ATTACHED" }, location.origin);
  if (typeof window.setInterval === "function") {
    window.setInterval(() => ensureCommandObserver(window.Entry), 500);
  }
})();
